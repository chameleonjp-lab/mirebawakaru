(function () {
  'use strict';
  const B = '#f7f6f2', INK = '#28313a', GRAY = '#7d8891', LIGHT = '#d4dcda';
  const TEAL = '#087f73', CORAL = '#bf604e', TAU = Math.PI * 2;
  const rad = degrees => degrees * Math.PI / 180;
  const clamp = value => Math.max(0, Math.min(1, Number.isFinite(value) ? value : 0.5));

  function line(c, a, b, color = INK, width = 3, dash = []) {
    c.save(); c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]);
    c.strokeStyle = color; c.lineWidth = width; c.lineCap = 'butt'; c.setLineDash(dash); c.stroke(); c.restore();
  }
  function path(c, points, color = INK, width = 3, close = false, fill = null) {
    c.save(); c.beginPath(); points.forEach((p, i) => i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1]));
    if (close) c.closePath();
    if (fill) { c.fillStyle = fill; c.fill(); }
    if (color) { c.strokeStyle = color; c.lineWidth = width; c.lineJoin = 'round'; c.stroke(); }
    c.restore();
  }
  function circle(c, x, y, r, fill = null, stroke = INK, width = 3) {
    c.save(); c.beginPath(); c.arc(x, y, r, 0, TAU);
    if (fill) { c.fillStyle = fill; c.fill(); }
    if (stroke) { c.strokeStyle = stroke; c.lineWidth = width; c.stroke(); }
    c.restore();
  }
  function text(c, words, x, y, size = 20, color = INK, align = 'center') {
    c.save(); c.font = `500 ${Math.max(18, size)}px system-ui, -apple-system, "Noto Sans JP", sans-serif`;
    c.textAlign = align; c.textBaseline = 'middle'; c.fillStyle = color; c.fillText(words, x, y); c.restore();
  }
  function arrow(c, a, b, color = INK, width = 2.5, tip = 9) {
    line(c, a, b, color, width);
    const theta = Math.atan2(b[1] - a[1], b[0] - a[0]);
    line(c, b, [b[0] - tip * Math.cos(theta - 0.5), b[1] - tip * Math.sin(theta - 0.5)], color, width);
    line(c, b, [b[0] - tip * Math.cos(theta + 0.5), b[1] - tip * Math.sin(theta + 0.5)], color, width);
  }
  function measure(c, a, b, label, labelAt, color = TEAL) {
    line(c, a, b, color, 2);
    const theta = Math.atan2(b[1] - a[1], b[0] - a[0]), dx = 6 * Math.sin(theta), dy = 6 * Math.cos(theta);
    [a, b].forEach(p => line(c, [p[0] - dx, p[1] + dy], [p[0] + dx, p[1] - dy], color, 2));
    if (label) text(c, label, labelAt[0], labelAt[1], 18, color);
  }
  function wrap(draw) {
    return function (ctx, state) {
      const s = Object.assign({ reveal: false, running: false, time: 0, value: 0.5, variant: 0, seed: 0 }, state || {});
      s.value = clamp(s.value); s.time = Math.max(0, Number(s.time) || 0);
      ctx.save(); ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
      ctx.setLineDash([]); ctx.fillStyle = B; ctx.fillRect(0, 0, 640, 400);
      try { draw(ctx, s); } finally { ctx.restore(); }
    };
  }
  function endpointGuides(c, x1, x2, top, bottom) {
    line(c, [x1, top], [x1, bottom], TEAL, 1.5, [5, 5]);
    line(c, [x2, top], [x2, bottom], TEAL, 1.5, [5, 5]);
  }

  const renderers = {};

  renderers.G01 = wrap((c, s) => {
    const x1 = 190, x2 = 450, wing = 24 + 42 * s.value;
    [130, 270].forEach((y, i) => {
      line(c, [x1, y], [x2, y], INK, 5);
      if (!s.reveal) {
        const sign = i === 0 ? 1 : -1;
        [-1, 1].forEach(dy => {
          line(c, [x1, y], [x1 + sign * wing, y + dy * wing], INK, 3.5);
          line(c, [x2, y], [x2 - sign * wing, y + dy * wing], INK, 3.5);
        });
      }
    });
    text(c, 'A', 105, 130); text(c, 'B', 105, 270);
    if (s.reveal) {
      endpointGuides(c, x1, x2, 95, 305);
      measure(c, [x1, 335], [x2, 335], '260 = 260', [320, 365]);
    }
  });

  renderers.G02 = wrap((c, s) => {
    if (!s.reveal) {
      const topHalf = (170 - 120 * s.value) / 2;
      [-1, 1].forEach(sign => line(c, [320 + sign * topHalf, 55], [320 + sign * 205, 340], GRAY, 3));
      for (let i = 1; i <= 7; i++) {
        const t = (i / 8) ** 1.6, y = 55 + 285 * t, half = topHalf + (205 - topHalf) * t;
        line(c, [320 - half, y], [320 + half, y], '#a8b0b2', 2);
      }
    }
    [125, 270].forEach(y => line(c, [240, y], [400, y], INK, 9));
    if (s.reveal) {
      endpointGuides(c, 240, 400, 95, 300);
      measure(c, [240, 335], [400, 335], '160 = 160', [320, 365]);
    }
  });

  renderers.G03 = wrap((c, s) => {
    if (!s.reveal) {
      [[180, 7, 93, 37], [460, 8, 61, 13]].forEach(([x, n, orbit, r]) => {
        for (let i = 0; i < n; i++) {
          const a = TAU * i / n + (n === 7 ? Math.PI / 2 : 0);
          circle(c, x + orbit * Math.cos(a), 195 + orbit * Math.sin(a), r, LIGHT, INK, 2);
        }
      });
    }
    [180, 460].forEach(x => {
      circle(c, x, 195, 25, INK, null);
      if (s.reveal) {
        line(c, [x - 25, 195], [x - 25, 270], TEAL, 1, [4, 4]);
        line(c, [x + 25, 195], [x + 25, 270], TEAL, 1, [4, 4]);
        measure(c, [x - 25, 265], [x + 25, 265], '直径50', [x, 300]);
      }
    });
    text(c, 'A', 180, 350); text(c, 'B', 460, 350);
  });

  renderers.G04 = wrap((c, s) => {
    const outer = [44, 70 + 55 * s.value];
    [175, 465].forEach((x, i) => {
      if (!s.reveal) circle(c, x, 195, outer[(i + (s.variant % 2)) % 2], null, INK, 3);
      circle(c, x, 195, 34, INK, null);
      if (s.reveal) {
        measure(c, [x - 34, 265], [x + 34, 265], '直径68', [x, 300]);
        line(c, [x - 34, 195], [x - 34, 270], TEAL, 1, [4, 4]);
        line(c, [x + 34, 195], [x + 34, 270], TEAL, 1, [4, 4]);
      }
    });
    text(c, 'A', 175, 350); text(c, 'B', 465, 350);
  });

  function annularSector(c, x, y, fill, stroke = INK, width = 3, dash = []) {
    c.save(); c.beginPath(); c.arc(x, y, 270, rad(-130), rad(-50));
    c.arc(x, y, 218, rad(-50), rad(-130), true); c.closePath();
    if (fill) { c.fillStyle = fill; c.fill(); }
    c.strokeStyle = stroke; c.lineWidth = width; c.setLineDash(dash); c.stroke(); c.restore();
  }
  renderers.G05 = wrap((c, s) => {
    if (!s.reveal) {
      annularSector(c, 330, 360, '#c8d0ce');
      annularSector(c, 297, 460, '#c8d0ce');
      text(c, 'A', 100, 135); text(c, 'B', 100, 270);
    } else {
      annularSector(c, 320, 420, '#e3e9e4', TEAL, 6);
      annularSector(c, 320, 420, null, CORAL, 2.5, [8, 5]);
      text(c, '2つの帯を同じ位置に重ねる', 320, 65, 22);
      text(c, '外側の弧も、内側の弧も一致', 320, 340, 20, TEAL);
    }
  });

  renderers.G06 = wrap((c, s) => {
    if (!s.reveal) {
      line(c, [210, 300], [430, 300], INK, 5);
      line(c, [320, 80], [320, 300], INK, 5);
      text(c, '縦', 360, 170); text(c, '横', 320, 345);
    } else {
      line(c, [210, 140], [430, 140], CORAL, 5);
      line(c, [210, 260], [430, 260], INK, 5);
      endpointGuides(c, 210, 430, 110, 290);
      text(c, '元の縦', 115, 140); text(c, '元の横', 115, 260);
      measure(c, [210, 325], [430, 325], '220 = 220', [320, 360]);
    }
  });

  renderers.G07 = wrap((c, s) => {
    const n = 3 + Math.round(14 * s.value);
    if (!s.reveal) for (let i = 1; i <= n; i++) {
      const x = 100 + 220 * i / (n + 1); line(c, [x, 177], [x, 223], INK, 2.5);
    }
    [100, 320, 540].forEach((x, i) => {
      line(c, [x, 162], [x, 238], INK, 4);
      text(c, ['A', 'B', 'C'][i], x, 275);
    });
    if (s.reveal) {
      measure(c, [100, 320], [320, 320], '220', [210, 350]);
      measure(c, [320, 320], [540, 320], '220', [430, 350]);
    }
  });

  renderers.G08 = wrap((c, s) => {
    if (!s.reveal) {
      path(c, [[70, 100], [430, 100], [510, 280], [150, 280]], GRAY, 3, true);
      line(c, [330, 100], [410, 280], GRAY, 3);
      line(c, [150, 280], [330, 100], INK, 6);
      line(c, [330, 100], [510, 280], INK, 6);
      text(c, 'A', 220, 330); text(c, 'B', 440, 330);
    } else {
      const half = 90 * Math.SQRT2;
      line(c, [320 - half, 140], [320 + half, 140], INK, 5);
      line(c, [320 - half, 260], [320 + half, 260], CORAL, 5);
      endpointGuides(c, 320 - half, 320 + half, 110, 290);
      text(c, 'A', 115, 140); text(c, 'B', 115, 260);
      text(c, '回転して並べると、両端が一致', 320, 350, 20, TEAL);
    }
  });

  renderers.G09 = wrap((c, s) => {
    const w = 80 + 100 * s.value;
    line(c, [120, 310], [520, 90], INK, 5);
    c.save(); c.globalAlpha = s.reveal ? 0.12 : 1;
    c.fillStyle = '#c5cdcb'; c.fillRect(320 - w / 2, 55, w, 290);
    c.strokeStyle = GRAY; c.lineWidth = 2; c.strokeRect(320 - w / 2, 55, w, 290); c.restore();
    if (s.reveal) {
      line(c, [120, 310], [520, 90], TEAL, 3);
      circle(c, 120, 310, 5, TEAL, null); circle(c, 520, 90, 5, TEAL, null);
      text(c, '隠れていた部分も同じ直線', 320, 375, 20, TEAL);
    }
  });

  renderers.G10 = wrap((c, s) => {
    for (let i = 0; i < 5; i++) {
      const x = 80 + 100 * i;
      line(c, [x, 310], [x + 100, 90], INK, 4);
      if (!s.reveal) for (let j = 1; j <= 8; j++) {
        const t = j / 9, px = x + 100 * t, py = 310 - 220 * t;
        const d = i % 2 ? [0, 23] : [23, 0];
        line(c, [px - d[0], py - d[1]], [px + d[0], py + d[1]], INK, 2.5);
      }
    }
    if (s.reveal) {
      line(c, [60, 310], [500, 310], TEAL, 1.5, [5, 5]);
      line(c, [160, 90], [600, 90], TEAL, 1.5, [5, 5]);
      text(c, '同じ傾きの線を等間隔に移動', 320, 365, 20, TEAL);
    }
  });

  function heringTargets(c, reveal) {
    [230, 410].forEach(x => line(c, [x, 65], [x, 335], INK, 5));
    if (reveal) {
      measure(c, [230, 95], [410, 95], '180', [320, 70]);
      measure(c, [230, 305], [410, 305], '180', [320, 335]);
      text(c, '直線・同じ間隔', 320, 375, 20, TEAL);
    }
  }
  renderers.G11 = wrap((c, s) => {
    if (!s.reveal) {
      c.save(); c.beginPath(); c.rect(45, 45, 550, 310); c.clip();
      for (let i = 0; i < 18; i++) {
        const a = i * Math.PI / 18, dx = 650 * Math.cos(a), dy = 650 * Math.sin(a);
        line(c, [320 - dx, 200 - dy], [320 + dx, 200 + dy], '#969fa4', 1.6);
      }
      c.restore();
    }
    heringTargets(c, s.reveal);
  });
  renderers.G12 = wrap((c, s) => {
    if (!s.reveal) for (let y = 25; y <= 375; y += 25) {
      path(c, [[70, 200], [320, y], [570, 200]], '#969fa4', 1.6);
    }
    heringTargets(c, s.reveal);
  });

  renderers.G13 = wrap((c, s) => {
    if (!s.reveal) {
      c.save(); c.beginPath(); c.rect(50, 50, 540, 300); c.clip();
      for (let i = 0; i <= 24; i++) {
        const a = -Math.PI / 2 + i * Math.PI / 48;
        line(c, [100, 315], [100 + Math.cos(a) * 900, 315 + Math.sin(a) * 900], '#9aa3a6', 1.6);
      }
      c.restore();
    }
    path(c, [[265, 110], [455, 110], [455, 300], [265, 300]], INK, 5, true);
    if (s.reveal) {
      [[265, 110, 1, 1], [455, 110, -1, 1], [455, 300, -1, -1], [265, 300, 1, -1]].forEach(([x, y, a, b]) =>
        path(c, [[x + 14 * a, y], [x + 14 * a, y + 14 * b], [x, y + 14 * b]], TEAL, 2));
      measure(c, [265, 335], [455, 335], '190', [360, 365]);
      measure(c, [225, 110], [225, 300], '190', [185, 205]);
    }
  });

  renderers.G14 = wrap((c, s) => {
    const tile = 48, gap = 3, top = 32, left = 48, right = 592;
    // The animation changes only row offsets; every mortar y coordinate is fixed.
    const shift = tile * (s.value + 0.5 * Math.sin(s.time * 0.8));
    if (!s.reveal) {
      c.save(); c.beginPath(); c.rect(left, top, right - left, 306); c.clip();
      c.fillStyle = '#8d9496'; c.fillRect(left, top, right - left, 306);
      for (let row = 0; row < 6; row++) for (let col = -3; col < 15; col++) {
        const x = left + col * tile + (row % 2 ? shift : 0);
        c.fillStyle = col % 2 === 0 ? '#f9faf6' : '#30383c';
        c.fillRect(x, top + row * (tile + gap), tile, tile);
      }
      c.restore();
      if (!s.running) {
        // Static reference frames for the two useful phases of the periodic motion.
        [0, 0.5].forEach((offset, i) => {
          const px = i ? 400 : 165, py = 347, small = 12;
          c.save(); c.beginPath(); c.rect(px, py, 72, 25); c.clip();
          c.fillStyle = '#8d9496'; c.fillRect(px, py, 72, 25);
          for (let row = 0; row < 2; row++) for (let col = -1; col < 7; col++) {
            c.fillStyle = col % 2 === 0 ? '#f9faf6' : '#30383c';
            c.fillRect(px + col * small + (row ? offset * small : 0), py + row * 13, small, small);
          }
          c.restore(); text(c, i ? '半枚のずれ' : '整列', px + 36, 389, 18, GRAY);
        });
      }
    } else {
      for (let row = 0; row < 5; row++) {
        const y = top + tile + gap / 2 + row * (tile + gap);
        line(c, [left, y], [right, y], TEAL, 3);
      }
      text(c, '横の目地だけを残すと、すべて水平', 320, 380, 18, TEAL);
    }
  });

  renderers.G15 = wrap((c, s) => {
    const cx = 320, cy = 195, radii = [30, 55, 80, 105, 130, 155];
    if (!s.reveal) {
      c.save(); c.beginPath(); c.arc(cx, cy, 169, 0, TAU); c.clip();
      for (let row = -9; row <= 9; row++) for (let col = -9; col <= 9; col++) {
        c.fillStyle = (row + col) % 2 ? '#e2e5df' : '#f7f6f2';
        c.fillRect(cx + col * 20, cy + row * 20, 20, 20);
      }
      c.restore();
      radii.forEach(r => {
        c.save(); c.beginPath(); c.arc(cx, cy, r + 6, 0, TAU); c.arc(cx, cy, r - 6, 0, TAU, true); c.clip('evenodd');
        c.fillStyle = '#29323a'; c.fillRect(cx - r - 8, cy - r - 8, 2 * r + 16, 2 * r + 16);
        const n = Math.max(12, Math.round(TAU * r / 16)), tilt = 0.14 + 0.48 * s.value;
        for (let i = 0; i < n; i++) {
          const a = TAU * i / n;
          c.save(); c.translate(cx + r * Math.cos(a), cy + r * Math.sin(a)); c.rotate(a + Math.PI / 2 + tilt);
          c.fillStyle = '#f7f6f2'; c.fillRect(-4, -18, 8, 36); c.restore();
        }
        c.restore();
      });
    } else {
      radii.forEach(r => circle(c, cx, cy, r, null, TEAL, 3));
      circle(c, cx, cy, 3.5, CORAL, null);
      text(c, 'すべて閉じた同心円', 320, 380, 20, TEAL);
    }
  });

  function grating(c, x, y, radius, angle, spacing, width, color) {
    c.save(); c.beginPath(); c.arc(x, y, radius, 0, TAU); c.clip();
    c.fillStyle = B; c.fillRect(x - radius, y - radius, radius * 2, radius * 2);
    c.translate(x, y); c.rotate(angle);
    for (let q = -radius * 2; q <= radius * 2; q += spacing) line(c, [q, -radius * 2], [q, radius * 2], color, width);
    c.restore();
  }
  renderers.G16 = wrap((c, s) => {
    const angle = rad(5 + 30 * s.value);
    [170, 470].forEach((x, i) => {
      if (!s.reveal) grating(c, x, 195, 125, (i ? -1 : 1) * angle, 12, 4, '#65717a');
      circle(c, x, 195, 66, B, null);
      grating(c, x, 195, 60, 0, 10, 3.5, INK);
      if (s.reveal) line(c, [x, 105], [x, 285], TEAL, 2, [6, 5]);
      text(c, i ? 'B' : 'A', x, 350);
    });
  });

  const tableShape = [[-110, -45], [50, -45], [110, 45], [-50, 45]];
  function transformedTable(x, y, angle) {
    const ca = Math.cos(angle), sa = Math.sin(angle);
    return tableShape.map(([px, py]) => [x + px * ca - py * sa, y + px * sa + py * ca]);
  }
  function table(c, points, context) {
    if (context) {
      points.forEach(p => path(c, [[p[0] - 4, p[1]], [p[0] + 4, p[1]], [p[0] + 4, p[1] + 70], [p[0] - 4, p[1] + 70]], INK, 1.5, true, '#aeb9b4'));
      path(c, points.map(p => [p[0], p[1] + 9]), INK, 2, true, '#adb9b3');
    }
    path(c, points, INK, 2.5, true, '#d5dcd6');
  }
  renderers.G17 = wrap((c, s) => {
    const left = transformedTable(180, 185, rad(-70)), right = transformedTable(460, 170, 0);
    table(c, left, !s.reveal); table(c, right, !s.reveal);
    let t = (s.time % 8) / 8; t = t <= 0.5 ? 2 * t : 2 - 2 * t; t = t * t * (3 - 2 * t);
    if (s.reveal) t = 1;
    const moving = transformedTable(180 + 280 * t, 185 - 15 * t, rad(-70) * (1 - t));
    if (s.reveal || s.time > 0) {
      c.save(); c.globalAlpha = 0.16; path(c, moving, null, 0, true, TEAL); c.restore();
      path(c, moving, TEAL, 4.5, true);
    }
    if (!s.running && !s.reveal) {
      // Both drawn tabletops are the exact start and end outlines of the moving panel.
      text(c, '再生すると左の天板が回転して右に重なる', 320, 378, 18, GRAY);
    }
    if (s.reveal) text(c, '回転・移動だけで輪郭が一致', 320, 360, 20, TEAL);
  });

  function person(c, x, bottom, height, color = INK) {
    const r = height * 0.09;
    circle(c, x, bottom - height + r, r, color, null);
    line(c, [x, bottom - height + r * 2.4], [x, bottom - height * 0.36], color, Math.max(3, height * 0.045));
    line(c, [x - height * 0.18, bottom - height * 0.62], [x + height * 0.18, bottom - height * 0.62], color, Math.max(3, height * 0.035));
    line(c, [x, bottom - height * 0.36], [x - height * 0.13, bottom], color, Math.max(3, height * 0.04));
    line(c, [x, bottom - height * 0.36], [x + height * 0.13, bottom], color, Math.max(3, height * 0.04));
  }
  renderers.G18 = wrap((c, s) => {
    if (!s.reveal) {
      text(c, '固定視点からの見え（模式図）', 320, 28, 20);
      const inner = [[160, 80], [480, 80], [480, 300], [160, 300]];
      const outer = [[70, 50], [570, 50], [570, 345], [70, 345]];
      path(c, outer, GRAY, 2, true, '#eef0e9'); path(c, inner, GRAY, 2, true, '#e2e6df');
      inner.forEach((p, i) => line(c, p, outer[i], GRAY, 2));
      person(c, 205, 299, 82); person(c, 435, 299, 164);
      text(c, '同じ身長でも、写る高さは違う', 320, 377, 18, GRAY);
    } else {
      text(c, '上から見た配置（模式図）', 320, 28, 20);
      path(c, [[110, 80], [500, 225], [510, 315], [200, 315]], GRAY, 2.5, true, '#e3e8e2');
      const eye = [320, 358], far = [150, 105], near = [465, 220];
      line(c, eye, far, TEAL, 2, [6, 5]); line(c, eye, near, CORAL, 2, [6, 5]);
      circle(c, far[0], far[1], 9, TEAL, null); circle(c, near[0], near[1], 9, CORAL, null);
      circle(c, eye[0], eye[1], 7, INK, null);
      text(c, '遠い側', 155, 60, 19, TEAL); text(c, '近い側', 525, 185, 19, CORAL);
      text(c, '固定視点', 320, 386, 18); text(c, '人物の身長は同じ', 320, 147, 19);
    }
  });

  renderers.G19 = wrap((c, s) => {
    if (!s.reveal) {
      text(c, 'カメラに写る像（模式図）', 320, 45, 21);
      [185, 455].forEach(x => {
        c.save(); c.fillStyle = '#e4e8e1'; c.fillRect(x - 100, 95, 200, 220); c.restore();
        circle(c, x, 195, 56, '#a7b5af', INK, 3);
      });
      text(c, '同じ見かけでも、大きさと距離は別', 320, 355, 20);
    } else {
      text(c, '高さと距離を同じ比率で変える', 320, 35, 20);
      const eye = [90, 235];
      line(c, eye, [410, 135], GRAY, 2); line(c, eye, [410, 335], GRAY, 2);
      line(c, [250, 185], [250, 285], TEAL, 8);
      line(c, [410, 135], [410, 335], CORAL, 8);
      circle(c, eye[0], eye[1], 7, INK, null);
      text(c, '視点', 90, 275, 18); text(c, '高さ100', 265, 150, 18, TEAL); text(c, '高さ200', 465, 110, 18, CORAL);
      measure(c, [90, 365], [250, 365], '距離160', [170, 390], TEAL);
      measure(c, [250, 365], [410, 365], '+160', [330, 390], CORAL);
      text(c, '同じ2本の視線に収まる', 420, 75, 19);
    }
  });

  function key(c) {
    c.save(); c.fillStyle = INK; c.beginPath(); c.arc(-36, 0, 26, 0, TAU); c.arc(-36, 0, 12, 0, TAU, true); c.fill('evenodd');
    c.fillRect(-10, -7, 75, 14); c.fillRect(38, 5, 11, 21); c.fillRect(54, 5, 11, 30); c.restore();
  }
  renderers.G20 = wrap((c, s) => {
    const horizontal = s.reveal ? 1 : 2.8 - 1.8 * s.value;
    text(c, '投影の補正を、横伸縮で説明', 320, 50, 20);
    c.save(); c.translate(320, 185); c.scale(1.5 * horizontal, 1.5); key(c); c.restore();
    arrow(c, [180, 300], [260, 300], s.reveal ? TEAL : GRAY);
    arrow(c, [460, 300], [380, 300], s.reveal ? TEAL : GRAY);
    text(c, s.reveal ? '同じ経路を元の横倍率へ戻す' : '補正を動かして形を確かめる', 320, 355, 20, s.reveal ? TEAL : INK);
  });

  renderers.G21 = wrap((c, s) => {
    if (!s.reveal) {
      text(c, '等しい円による模式図', 320, 30, 20);
      path(c, [[0, 315], [80, 297], [140, 316], [220, 292], [280, 310], [340, 272], [380, 297], [430, 304], [485, 295], [550, 265], [640, 296], [640, 400], [0, 400]], null, 0, true, '#bcc7bf');
      path(c, [[336, 300], [336, 263], [354, 247], [372, 263], [372, 300]], GRAY, 2, true, '#e2e7de');
      line(c, [0, 304], [640, 304], GRAY, 1.5);
      circle(c, 180, 105, 28, B, INK, 2);
      circle(c, 460, 270, 28, B, INK, 2);
    } else {
      [180, 460].forEach(x => {
        circle(c, x, 190, 28, B, INK, 2);
        measure(c, [x - 28, 260], [x + 28, 260], '直径56', [x, 295]);
      });
      text(c, '背景を消して、同じ高さで比較', 320, 355, 20, TEAL);
    }
  });

  renderers.G22 = wrap((c, s) => {
    if (!s.reveal) {
      text(c, '凹面マスクの正面図（模式）', 320, 32, 20);
      c.save(); c.beginPath(); c.ellipse(320, 195, 92, 128, 0, 0, TAU);
      const shade = c.createLinearGradient(228, 195, 412, 195); shade.addColorStop(0, '#abb7b2'); shade.addColorStop(0.55, '#eef0e8'); shade.addColorStop(1, '#c4cec7');
      c.fillStyle = shade; c.fill(); c.strokeStyle = GRAY; c.lineWidth = 2; c.stroke();
      [[286, 175], [354, 175]].forEach(([x, y]) => { c.beginPath(); c.ellipse(x, y, 15, 7, 0, 0, TAU); c.fillStyle = '#73817b'; c.fill(); });
      path(c, [[320, 173], [306, 222], [329, 222]], '#97a39b', 4);
      c.beginPath(); c.moveTo(287, 259); c.quadraticCurveTo(320, 273, 353, 259); c.strokeStyle = '#78867e'; c.lineWidth = 4; c.stroke(); c.restore();
      text(c, '正面の絵だけでは、凹凸を一意に決めにくい', 320, 370, 18, GRAY);
    } else {
      text(c, '物体：凹面', 200, 42, 21, TEAL); text(c, '解釈の候補：凸面', 440, 42, 21, CORAL);
      line(c, [170, 85], [170, 310], GRAY, 1.5, [5, 5]); line(c, [470, 85], [470, 310], GRAY, 1.5, [5, 5]);
      const concave = [[170, 95], [184, 135], [188, 173], [235, 197], [188, 219], [184, 260], [170, 300]];
      const convex = concave.map(([x, y]) => [640 - x, y]);
      path(c, concave, TEAL, 5); path(c, convex, CORAL, 5);
      arrow(c, [75, 197], [145, 197], INK); arrow(c, [330, 197], [390, 197], INK);
      text(c, 'へこむ', 210, 338, 19, TEAL); text(c, '手前へ出る', 440, 338, 19, CORAL);
      text(c, '顔の断面を横から見た説明図', 320, 380, 18);
    }
  });

  // A three-prism open sculpture. Its endpoints differ by (1,1,1), which
  // projects to zero at the first view. The reveal uses another linear projection.
  function tribar(c, reveal) {
    const w = 0.06, size = 285;
    function project(p) {
      const depth = p[0] + p[1] + p[2] - 1.5;
      return [320 + size * (0.5 * p[0] - p[1] + 0.5 * p[2]) + (reveal ? 38 * depth : 0),
        65 + size * Math.sqrt(3) / 2 * (p[0] - p[2]) - (reveal ? 14 * depth : 0)];
    }
    const boxes = [
      [[0, 1], [-w, w], [-w, w]],
      [[1 - w, 1 + w], [0, 1], [-w, w]],
      [[1 - w, 1 + w], [1 - w, 1 + w], [0, 1]]
    ];
    const faces = [];
    boxes.forEach(bounds => {
      for (let axis = 0; axis < 3; axis++) {
        const other = [0, 1, 2].filter(a => a !== axis), points = [];
        [[0, 0], [1, 0], [1, 1], [0, 1]].forEach(bits => {
          const p = [0, 0, 0]; p[axis] = bounds[axis][1];
          p[other[0]] = bounds[other[0]][bits[0]]; p[other[1]] = bounds[other[1]][bits[1]]; points.push(p);
        });
        faces.push({ points, depth: points.reduce((sum, p) => sum + p[0] + p[1] + p[2], 0) / 4, axis });
      }
    });
    faces.sort((a, b) => a.depth - b.depth).forEach(f => path(c, f.points.map(project), INK, 1.6, true, ['#b9c5be', '#e0e7de', '#87998c'][f.axis]));
    if (reveal) {
      const start = project([0, 0, 0]), end = project([1, 1, 1]);
      line(c, start, end, CORAL, 2, [5, 5]);
      circle(c, start[0], start[1], 6, TEAL, null); circle(c, end[0], end[1], 6, CORAL, null);
    }
  }
  renderers.G23 = wrap((c, s) => {
    tribar(c, s.reveal);
    text(c, s.reveal ? '視点をずらすと、重なった端が離れる' : '3つの接合部を順にたどる', 320, 377, 18, s.reveal ? TEAL : GRAY);
  });

  renderers.G24 = wrap((c, s) => {
    if (!s.reveal) {
      text(c, '不可能な接続を考える模式図', 320, 30, 20);
      const vertices = [[320, 85], [535, 190], [320, 295], [105, 190]];
      for (let k = 0; k < 4; k++) {
        const a = vertices[k], b = vertices[(k + 1) % 4], dx = b[0] - a[0], dy = b[1] - a[1], length = Math.hypot(dx, dy);
        const nx = -dy / length * 21, ny = dx / length * 21;
        for (let j = 0; j < 3; j++) {
          const p = [a[0] + dx * j / 3, a[1] + dy * j / 3], q = [a[0] + dx * (j + 1) / 3, a[1] + dy * (j + 1) / 3];
          const p1 = [p[0] - nx, p[1] - ny], p2 = [p[0] + nx, p[1] + ny], q1 = [q[0] - nx, q[1] - ny], q2 = [q[0] + nx, q[1] + ny];
          path(c, [q1, q2, [q2[0], q2[1] + 10], [q1[0], q1[1] + 10]], INK, 1.2, true, '#85978c');
          path(c, [p1, q1, q2, p2], INK, 1.6, true, j % 2 ? '#d4dfd3' : '#e5ebe1');
        }
        arrow(c, [a[0] + dx * 0.35, a[1] + dy * 0.35], [a[0] + dx * 0.65, a[1] + dy * 0.65], INK, 2.5, 9);
      }
      text(c, '一周、すべて上り？', 320, 190, 20);
      text(c, '12段を上って出発点へ戻る、と読むと矛盾', 320, 365, 18, GRAY);
    } else {
      text(c, '一列に開くと、終点は高くなる', 320, 55, 21);
      const points = [[80, 300]];
      for (let i = 0; i < 12; i++) { points.push([80 + 35 * (i + 1), 300 - 12 * i]); points.push([80 + 35 * (i + 1), 300 - 12 * (i + 1)]); }
      path(c, points.concat([[500, 345], [80, 345]]), null, 0, true, '#e0e8df');
      path(c, points, TEAL, 4);
      line(c, [80, 300], [570, 300], GRAY, 1.5, [5, 5]);
      measure(c, [550, 156], [550, 300], '+12段', [590, 225], CORAL);
      text(c, '出発', 80, 365, 18); text(c, '終点', 500, 125, 18);
      text(c, '同じ高さへは戻れない', 320, 385, 18, TEAL);
    }
  });

  window.ILLUSION_RENDERERS = Object.assign(window.ILLUSION_RENDERERS || {}, renderers);
}());
