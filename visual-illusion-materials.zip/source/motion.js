(function () {
  'use strict';
  const R = {}, PI = Math.PI, TAU = PI * 2;
  // Capture the first displayed flash frame, not an ideal continuous-time crossing.
  // Per-context data only; the renderer owns no clock or animation loop.
  const flashFrames = new WeakMap();
  const C = {bg:'#f5f7fa', ink:'#233648', muted:'#617487', pale:'#d9e2e9', teal:'#287e7a', orange:'#cf6545', blue:'#4b78aa'};
  const val = s => Math.max(0, Math.min(1, Number.isFinite(s.value) ? s.value : .5));
  const time = s => Math.max(0, s.time || 0);
  const mod = (x,m) => ((x % m) + m) % m;
  const rand = (i,seed=1) => { const x=Math.sin(i*127.1+seed*311.7)*43758.5453; return x-Math.floor(x); };
  function text(c,t,x,y,size=20,color=C.ink,align='center') {c.fillStyle=color;c.font=`${size}px "Noto Sans JP", "Noto Sans CJK JP", sans-serif`;c.textAlign=align;c.textBaseline='middle';c.fillText(t,x,y);}
  function line(c,x1,y1,x2,y2,color=C.ink,w=2,dash=[]) {c.save();c.strokeStyle=color;c.lineWidth=w;c.setLineDash(dash);c.beginPath();c.moveTo(x1,y1);c.lineTo(x2,y2);c.stroke();c.restore();}
  function circle(c,x,y,r,fill,stroke,w=2) {c.beginPath();c.arc(x,y,r,0,TAU);if(fill){c.fillStyle=fill;c.fill();}if(stroke){c.strokeStyle=stroke;c.lineWidth=w;c.stroke();}}
  function rect(c,x,y,w,h,fill,stroke,sw=2) {if(fill){c.fillStyle=fill;c.fillRect(x,y,w,h);}if(stroke){c.strokeStyle=stroke;c.lineWidth=sw;c.strokeRect(x,y,w,h);}}
  function arrow(c,x1,y1,x2,y2,color=C.orange,w=3) {line(c,x1,y1,x2,y2,color,w);const a=Math.atan2(y2-y1,x2-x1);line(c,x2,y2,x2-11*Math.cos(a-.45),y2-11*Math.sin(a-.45),color,w);line(c,x2,y2,x2-11*Math.cos(a+.45),y2-11*Math.sin(a+.45),color,w);}
  function cross(c,x,y,r=8,color=C.ink,w=2) {line(c,x-r,y,x+r,y,color,w);line(c,x,y-r,x,y+r,color,w);}
  function polygon(c,pts,fill,stroke,w=2) {c.beginPath();pts.forEach((p,i)=>i?c.lineTo(...p):c.moveTo(...p));c.closePath();if(fill){c.fillStyle=fill;c.fill();}if(stroke){c.strokeStyle=stroke;c.lineWidth=w;c.stroke();}}
  function title(c,t){text(c,t,320,28,21);}
  function footer(c,t){text(c,t,320,376,18,C.muted);}
  function grid(c,x,y,w,h,step=30,color=C.pale){for(let a=x;a<=x+w;a+=step)line(c,a,y,a,y+h,color,1);for(let b=y;b<=y+h;b+=step)line(c,x,b,x+w,b,color,1);}
  function neutral(c,label='静止した比較画面') {rect(c,95,70,450,260,'#e1e4e6');grid(c,95,70,450,260,30,'#aab2b7');cross(c,320,200);title(c,label);}
  function stopped(s,limit=8) {return time(s)>=limit || (time(s)>0 && !s.running);}
  function register(id,fn){R[id]=(c,s)=>{c.save();rect(c,0,0,640,400,C.bg);c.lineCap='round';c.lineJoin='round';fn(c,s);c.restore();};}

  register('M01',(c,s)=>{
    title(c,'純粋ファイとベータの違い：模式図');
    const delay=Math.round(40+val(s)*260);
    [130,320,510].forEach((x,i)=>{rect(c,x-78,80,156,105,'#e8edf2',C.pale);text(c,['刺激 A','間の印象','刺激 B'][i],x,62,18);});
    circle(c,130,132,19,C.ink);circle(c,510,132,19,C.ink);
    if(!s.reveal){c.save();c.globalAlpha=.17;for(let i=0;i<9;i++)circle(c,280+i*10,132,15,C.ink);c.restore();text(c,'動きの感じ',320,166,18);}
    else {text(c,'物体の描画なし',320,132,18,C.orange);line(c,70,210,570,210,C.pale,2);[130,510].forEach(x=>{line(c,x,82,x,230,C.orange,2,[5,5]);circle(c,x,210,5,C.orange);});}
    text(c,'ファイ：対象が移ったという印象を伴わない動き',320,253,19);
    text(c,'ベータ：同じ対象が A → B へ移ったように見える',320,290,19);
    line(c,135,328,505,328,C.pale,2);rect(c,160,316,26,24,C.ink);const tx=240+val(s)*220;rect(c,tx,316,26,24,C.ink);arrow(c,192,328,tx-8,328,C.muted,2);text(c,`提示間隔の概念値 ${delay} ms`,320,352,18,C.muted);
    footer(c,'この図は点滅実験ではなく、知覚の区別を表す。');
  });

  register('M02',(c,s)=>{
    title(c,'離れた位置だけを順に表示');
    const step=.45+.4*val(s),n=Math.floor(time(s)/step)%6;
    if(s.reveal){for(let i=0;i<6;i++){circle(c,140+i*72,200,23,null,C.pale,2);text(c,String(i+1),140+i*72,250,18,C.muted);}line(c,140,200,500,200,C.pale,2,[4,6]);}
    circle(c,140+n*72,200,19,C.teal);text(c,`1コマ ${Math.round(step*1000)} ms`,320,300,19,C.muted);
    footer(c,s.reveal?'輪郭の場所だけに描画。中間位置は描いていない。':'再生して、別の出現と1つの移動の印象を比べる。');
  });

  register('M03',(c,s)=>{
    title(c,'逆ファイ：コマごとの比較（模式図）');
    const shift=12+Math.round(val(s)*24);
    [70,350].forEach(x=>rect(c,x,83,220,210,'#aab0b5',C.pale));
    text(c,'コマ A',180,61,20);text(c,'コマ B：明暗を反転',460,61,20);
    rect(c,140,143,60,75,'#37414a');rect(c,420+shift,143,60,75,'#f1f2f3');
    circle(c,170,178,10,'#f1f2f3');circle(c,450+shift,178,10,'#37414a');
    line(c,112,250,248,250,'#626e79',2);line(c,392,250,528,250,'#626e79',2);
    if(s.reveal){[140,200].forEach(x=>{line(c,x,130,x,255,C.orange,2,[5,4]);line(c,x+280,130,x+280,255,C.orange,2,[5,4]);arrow(c,x+280,263,x+280+shift,263,C.orange,2);});}
    arrow(c,130,322,250,322,C.orange);text(c,'輪郭の変位 →',190,350,19,C.orange);
    arrow(c,510,322,390,322,C.blue);text(c,'知覚しうる向き ←',450,350,19,C.blue);
    footer(c,'高速点滅は行わない。左右は同じ特徴の対応を示す。');
  });

  register('M04',(c,s)=>{
    title(c,'この模様は、まったく動いていない');
    const amp=.35+.65*val(s),base=[28,100,242,179];
    [[190,130],[450,130],[190,285],[450,285]].forEach(([x,y],j)=>{
      for(let i=0;i<48;i++){const a=i*TAU/48,b=(i+1)*TAU/48;const v=Math.round(135+(base[(j%2?47-i:i)%4]-135)*amp);c.beginPath();c.arc(x,y,61,a,b);c.arc(x,y,28,b,a,true);c.closePath();c.fillStyle=`rgb(${v},${v},${v})`;c.fill();}
      if(s.reveal){cross(c,x,y,10,C.orange);for(let k=0;k<8;k++){const a=k*TAU/8;line(c,x+64*Math.cos(a),y+64*Math.sin(a),x+71*Math.cos(a),y+71*Math.sin(a),C.orange,3);}circle(c,x,y,72,null,C.orange,1);}
    });
    footer(c,s.reveal?'固定の中心と目盛り。図形の位置・角度は更新しない。':'自然に視線を移す。見え方の強さには個人差がある。');
  });

  register('M05',(c,s)=>{
    title(c,'中央と周囲で、長方形の向きが異なる');
    const a=18+val(s)*18,b=7;
    function checks(vertical){for(let y=50;y<350;y+=vertical?a:b)for(let x=80;x<560;x+=vertical?b:a){const i=Math.floor((x-80)/(vertical?b:a)),j=Math.floor((y-50)/(vertical?a:b));rect(c,x,y,vertical?b:a,vertical?a:b,(i+j)%2?'#e7ecee':'#324753');}}
    c.save();c.beginPath();c.rect(80,50,480,300);c.clip();checks(false);c.restore();
    if(!s.reveal){c.save();c.beginPath();c.arc(320,200,97,0,TAU);c.clip();checks(true);c.restore();}
    if(s.reveal){circle(c,320,200,97,null,C.orange,3);cross(c,320,200,10,C.orange);}
    footer(c,s.reveal?'模様の向きをそろえると、相対的な滑りの手がかりが減る。':'画面を揺らす処理はない。自然な視線移動で観察する。');
  });

  register('M06',(c,s)=>{
    if(stopped(s)||s.reveal){neutral(c,'比較：格子は静止している');footer(c,'必要なだけ休む。8秒以上の順応は行わない。');return;}
    title(c,s.running?'中央を楽に見る：8秒で静止格子へ':'再生すると流れる模様を8秒だけ表示');
    c.save();c.beginPath();c.rect(95,75,450,250);c.clip();
    const d=time(s)*(18+val(s)*38);
    for(let x=95;x<545;x+=2){const lum=Math.round(168+38*Math.sin((x-d)*TAU/76));rect(c,x,75,2,250,`rgb(${lum},${lum},${lum})`);}
    c.restore();cross(c,320,200,7,C.ink);rect(c,95,343,450,5,C.pale);rect(c,95,343,450*Math.min(1,time(s)/8),5,C.teal);
    footer(c,s.running?`あと ${Math.max(0,Math.ceil(8-time(s)))} 秒。停止すると直ちに静止格子へ。`:'短い弱めの刺激なので、残効が出ない場合もある。');
  });

  register('M07',(c,s)=>{
    title(c,'周囲の枠だけを動かす');const x=320+Math.sin(time(s)*.8)*(20+val(s)*55);
    if(s.reveal){grid(c,70,70,500,260,30);cross(c,320,200,22,C.orange);line(c,320,60,320,340,C.orange,2,[5,5]);}
    rect(c,x-200,88,400,224,null,C.teal,5);for(let i=-3;i<=3;i++)line(c,x+i*50,88,x+i*50,108,C.teal,4);
    circle(c,320,200,13,C.orange);footer(c,s.reveal?'点の座標は常に (320, 200)。動いているのは枠。':'中央の点が、枠と反対へ動くように見えることがある。');
  });

  register('M08',(c,s)=>{
    title(c,'中心から外へ広がるオプティックフロー');const seed=s.seed||1;
    rect(c,70,66,500,270,'#26394c');
    c.save();c.beginPath();c.rect(70,66,500,270);c.clip();
    for(let i=0;i<100;i++){const a=rand(i,seed)*TAU,base=.06+rand(i+120,seed)*.9;const r=.06*Math.exp(mod(Math.log(base/.06)+time(s)*(.2+.26*val(s)),Math.log(1/.06)));circle(c,320+250*r*Math.cos(a),201+136*r*Math.sin(a),1.5+r*2,'#c3d9e2');}
    if(s.reveal)for(let i=0;i<8;i++){const a=i*TAU/8;arrow(c,320+90*Math.cos(a),201+48*Math.sin(a),320+185*Math.cos(a),201+100*Math.sin(a),'#e0a082',2);}
    c.restore();rect(c,70,66,500,270,null,s.reveal?C.orange:C.pale,3);cross(c,320,201,6,'#f0f3f5');
    footer(c,s.reveal?'画面の枠は静止し、点だけが外へ移動している。':'小窓では自己運動感が弱い。違和感があれば停止する。');
  });

  register('M09',(c,s)=>{
    title(c,'窓の内側だけでは、線の全方向は分からない');const dx=48*Math.sin(time(s)*(.5+.5*val(s)));
    if(s.reveal){grid(c,90,55,460,280,35);line(c,180+dx,330,460+dx,50,C.teal,8);circle(c,180+dx,330,6,C.orange);circle(c,460+dx,50,6,C.orange);}
    else {circle(c,320,190,100,'#e2e8ed');c.save();c.beginPath();c.arc(320,190,100,0,TAU);c.clip();line(c,180+dx,330,460+dx,50,C.teal,8);c.restore();}
    circle(c,320,190,100,null,C.ink,3);
    if(s.reveal){arrow(c,420,302,490,302,C.orange,3);arrow(c,490,302,420,302,C.orange,3);text(c,'実際は水平',455,331,18,C.orange);arrow(c,275,160,325,210,C.blue,3);arrow(c,325,210,275,160,C.blue,3);text(c,'局所の成分',213,230,18,C.blue);}
    footer(c,s.reveal?'端点を見せると、水平方向の移動を追える。':'再生して観察。確認すると隠れていた線の端が現れる。');
  });

  register('M10',(c,s)=>{
    title(c,'窓の長軸と、見かけの流れ');const v=val(s),w=80+260*v*v,h=285-150*v*v,x=320-w/2,y=200-h/2,shift=mod(time(s)*28,48);
    function stripes(alpha){c.save();c.globalAlpha=alpha;for(let k=-550;k<1050;k+=48)line(c,k+shift,-100,k+shift-500,400,C.teal,18);c.restore();}
    if(s.reveal){c.save();c.beginPath();c.rect(65,55,510,285);c.clip();stripes(.23);c.restore();}
    rect(c,x,y,w,h,'#e4ebeb');c.save();c.beginPath();c.rect(x,y,w,h);c.clip();stripes(1);c.restore();rect(c,x,y,w,h,null,C.ink,4);
    if(s.reveal){arrow(c,460,315,545,315,C.orange,3);text(c,'縞の実移動',500,343,18,C.orange);for(let k=-300;k<1000;k+=48){const xx=k+shift-y;if(xx>x&&xx<x+w)circle(c,xx,y,4,C.orange);}}
    footer(c,s.reveal?'同じ縞を窓で切り取ると、端の交点の動きが手がかりになる。':'縦長・横長で印象を比べる。下地は水平に移動。');
  });

  register('M11',(c,s)=>{
    title(c,'同じ回転を、異なる時間間隔で表示');const speed=.4+.45*val(s),t=time(s),a=t*TAU*speed,b=Math.floor(t*6)/6*TAU*speed;
    function wheel(x,ang,mark){circle(c,x,215,96,null,C.ink,4);for(let i=0;i<8;i++){const q=ang+i*TAU/8;line(c,x,215,x+91*Math.cos(q),215+91*Math.sin(q),i===0&&mark?C.orange:C.ink,i===0&&mark?6:4);}circle(c,x,215,10,C.ink);}
    wheel(170,a,true);wheel(470,b,s.reveal);text(c,'連続的に更新',170,70,20);text(c,'毎秒6コマ',470,70,20);text(c,`${(speed*60).toFixed(1)} 回転／分`,320,332,19,C.muted);
    if(s.reveal){arrow(c,105,100,220,100,C.orange,3);arrow(c,405,100,520,100,C.orange,3);text(c,'橙色は同じスポーク',320,354,18,C.orange);}
    footer(c,s.reveal?'右も元の回転方向は一定。目印で真の対応を確かめる。':'同形のスポークでは、別のスポークとの対応が曖昧になる。');
  });

  register('M12',(c,s)=>{
    title(c,'短く出る印と、動く点の横位置');
    const rate=.9+.4*val(s),t=time(s),phase=t*rate,cycle=Math.floor(phase/PI);
    let x=320+170*Math.sin(phase),flash=mod(phase,PI)<rate*.1;
    let record=flashFrames.get(c);
    if(!record||t<record.lastTime||rate!==record.rate||s.seed!==record.seed||s.variant!==record.variant){
      record={lastTime:t,rate,seed:s.seed,variant:s.variant,active:false,cycle:-1,captureX:320,hasCapture:false};
      flashFrames.set(c,record);
    }
    if(!s.reveal){
      if(flash&&(!record.active||cycle!==record.cycle)){record.captureX=x;record.hasCapture=true;record.cycle=cycle;}
      record.active=flash;record.lastTime=t;
    }
    let markX=record.captureX;
    if(s.reveal){x=markX;flash=true;line(c,x,95,x,305,C.orange,2,[6,5]);}
    line(c,130,168,510,168,C.pale,2);circle(c,x,168,16,C.teal);if(flash)rect(c,markX-9,223,18,45,C.orange);
    cross(c,320,318,6,C.ink);text(c,s.reveal?(record.hasCapture?'印が出たフレームの位置に戻す':'初期位置の比較（出現記録なし）'):'印は約2〜4秒ごとに短く表示',320,76,19,C.muted);
    footer(c,s.reveal?'出現フレームでは、点と印が同じ横位置で始まる。':'印は出現位置に留まり、点だけが移動を続ける。');
  });

  register('M13',(c,s)=>{
    title(c,'同じ速度の2つの長方形');const contrast=s.reveal?0:val(s),x=100+320*(1-Math.cos(time(s)*.65))/2;
    rect(c,70,70,500,260,'#abb3b6');for(let i=0;i<36;i++){const lum=Math.round(170+(i%2?65:-115)*contrast);rect(c,70+i*14,70,14,260,`rgb(${lum},${lum},${lum})`);}
    if(s.reveal)line(c,x+28,118,x+28,276,C.orange,3);
    rect(c,x,125,56,34,'#2d3c46');rect(c,x,235,56,34,'#eee2af');
    if(s.reveal){line(c,x,115,x,284,C.orange,2,[5,4]);line(c,x+56,115,x+56,284,C.orange,2,[5,4]);}
    footer(c,s.reveal?'先端も後端も、上下で常に同じ横座標。':'縞のコントラストを下げると同期が分かりやすい。');
  });

  register('M14',(c,s)=>{
    rect(c,0,0,640,400,'#c6c7c9');const t=time(s),idle=!s.running&&t===0;
    if(stopped(s)){title(c,'終了：無彩色の静止画面');cross(c,320,200,7,'#51565b');footer(c,'残像が消えるまで楽に視線を動かし、休む。');return;}
    title(c,idle?'再生後、中央を8秒以内で楽に見る':'紫の点の「抜けた位置」を観察');const gap=Math.floor(t/.27)%12;
    for(let i=0;i<12;i++){const a=i*TAU/12-PI/2,x=320+111*Math.cos(a),y=205+111*Math.sin(a);
      if(idle){circle(c,x,y,18,null,'#8e9297',2);continue;}
      if(i!==gap){const g=c.createRadialGradient(x,y,2,x,y,24);g.addColorStop(0,`rgba(173,77,163,${.35+.4*val(s)})`);g.addColorStop(1,'rgba(173,77,163,0)');circle(c,x,y,24,g);}
      if(s.reveal)circle(c,x,y,21,null,i===gap?'#45484d':'#a0a3a7',i===gap?3:1);
    }
    cross(c,320,205,7,'#3e4349');footer(c,s.reveal?'緑の点は描画せず、1か所を灰色の背景に戻している。':idle?'初期画面は配置だけ。再生時に紫の刺激を表示。':`あと ${Math.ceil(8-t)} 秒で無彩色画面へ。`);
  });

  register('M15',(c,s)=>{
    const end=stopped(s),showField=!s.reveal&&!end,t=time(s);title(c,end?'終了：静止した3つの点':'背景が動いても、3つの点は描き続ける');
    rect(c,85,55,470,285,showField?'#25354a':'#e7e9eb');
    if(showField){c.save();c.beginPath();c.rect(85,55,470,285);c.clip();c.translate(320,200);c.rotate(t*(.07+.18*val(s)));for(let x=-250;x<260;x+=29)for(let y=-250;y<260;y+=29)cross(c,x,y,4,'#62839e',2);c.restore();}
    [[215,140],[425,140],[320,285]].forEach(([x,y])=>{circle(c,x,y,6,'#e3c76d');if(s.reveal||end)circle(c,x,y,17,null,C.orange,2);});cross(c,320,200,7,showField?'#edf1f6':C.ink);
    footer(c,end?'背景を除去。消失の有無は診断や成績ではない。':s.reveal?'背景を隠し、点の固定座標を示す。':'8秒以内。長く見続けず、見えなくても延長しない。');
  });

  register('M16',(c,s)=>{
    title(c,'点の運動から円筒の奥行きが立ち上がる');const angle=.35+time(s)*(.3+.45*val(s)),seed=s.seed||2;
    const points=[];for(let i=0;i<160;i++){const a=rand(i,seed)*TAU+angle;points.push({x:320+145*Math.cos(a),y:76+246*rand(i+200,seed),z:Math.sin(a)});}
    points.sort((a,b)=>a.z-b.z);points.forEach(p=>circle(c,p.x,p.y,3.5,s.reveal?(p.z>0?C.orange:C.blue):C.teal));
    if(s.reveal){line(c,320,53,320,340,C.muted,2,[5,6]);c.beginPath();c.ellipse(320,330,145,18,0,0,TAU);c.strokeStyle=C.pale;c.lineWidth=2;c.stroke();text(c,'暖色＝手前　寒色＝奥',320,352,18);}
    footer(c,s.reveal?'色は生成モデルの前後。平面上の点に深さの手がかりを追加。':'同じ点の明るさだけでは、前後が曖昧になることもある。');
  });

  register('M17',(c,s)=>{
    title(c,'陰影のない回転人形：独自の簡略例');const a=.55+time(s)*(.35+.5*val(s));
    const pts={neck:[0,137,0],hip:[0,235,0],lh:[-86,173,20],rh:[78,158,-20],lf:[-55,321,35],rf:[52,313,-35]};
    function p(q){return [320+q[0]*Math.cos(a)+q[2]*Math.sin(a),q[1],-q[0]*Math.sin(a)+q[2]*Math.cos(a)];}
    const seg=[['neck','lh'],['neck','rh'],['hip','lf'],['hip','rf']].map(([u,v])=>[p(pts[u]),p(pts[v])]);seg.sort((x,y)=>x[1][2]-y[1][2]);
    seg.forEach(([u,v])=>line(c,u[0],u[1],v[0],v[1],s.reveal?(v[2]>0?C.orange:C.blue):C.ink,22));line(c,320,140,320,235,C.ink,34);circle(c,320,102,27,C.ink);
    if(s.reveal){text(c,'暖色＝手前　寒色＝奥',320,348,18);}
    line(c,205,337,435,337,C.pale,2);footer(c,s.reveal?'前後の色を加えた生成モデル。元の回転方向は一定。':'回転の見え方から、性格や「利き脳」は判定できない。');
  });

  register('M18',(c,s)=>{
    title(c,'手前の面は、どちらにも読める');const A=[[190,145],[360,145],[360,315],[190,315]],B=A.map(([x,y])=>[x+95,y-75]);
    if(s.reveal)polygon(c,val(s)<.5?A:B,'#dfb09a',null);
    [A,B].forEach(p=>polygon(c,p,null,C.ink,4));for(let i=0;i<4;i++)line(c,...A[i],...B[i],C.ink,4);
    if(s.reveal){const p=val(s)<.5?A:B;circle(c,p[0][0],p[0][1],7,C.orange);text(c,'選んだ面を強調',480,320,18,C.orange);}
    footer(c,s.reveal?'線の位置は同じ。色を付けた面が解釈の手がかりになる。':'固定された線画。どちらか一方だけが正解ではない。');
  });

  function vasePath(c){c.beginPath();c.moveTo(230,65);c.bezierCurveTo(235,95,260,105,261,124);c.bezierCurveTo(266,139,249,146,267,154);c.bezierCurveTo(274,158,265,164,261,170);c.bezierCurveTo(268,176,261,186,256,192);c.bezierCurveTo(259,217,238,228,235,258);c.bezierCurveTo(229,293,210,315,202,326);c.lineTo(438,326);c.bezierCurveTo(430,315,411,293,405,258);c.bezierCurveTo(402,228,381,217,384,192);c.bezierCurveTo(379,186,372,176,379,170);c.bezierCurveTo(375,164,366,158,373,154);c.bezierCurveTo(391,146,374,139,379,124);c.bezierCurveTo(380,105,405,95,410,65);c.closePath();}
  register('M19',(c,s)=>{
    title(c,'同じ境界が、壺と横顔の両方になる');const faces=s.reveal&&val(s)>=.5;
    rect(c,85,52,470,290,faces?'#79a8a8':C.ink);vasePath(c);c.fillStyle=s.reveal&&!faces?'#e1ab91':'#f1f1ec';c.fill();
    if(s.reveal){if(faces){circle(c,219,142,5,C.ink);circle(c,421,142,5,C.ink);text(c,'横顔',146,288,20,'#f5f7fa');text(c,'横顔',493,288,20,'#f5f7fa');}else text(c,'壺',320,258,25,C.ink);}
    footer(c,s.reveal?'図と地の割り当てを変える。境界曲線は変更しない。':'中央の白い部分と、左右の暗い部分を順に意識する。');
  });

  function duckPath(c){c.beginPath();c.moveTo(390,134);c.bezierCurveTo(350,109,308,117,280,135);c.lineTo(159,91);c.bezierCurveTo(135,86,130,105,159,120);c.lineTo(266,167);c.lineTo(146,157);c.bezierCurveTo(127,159,136,180,160,184);c.lineTo(264,194);c.bezierCurveTo(267,256,300,282,360,280);c.bezierCurveTo(407,279,432,255,444,234);c.bezierCurveTo(459,232,465,222,450,213);c.bezierCurveTo(444,171,423,150,390,134);c.closePath();}
  register('M20',(c,s)=>{
    title(c,'アヒル／ウサギ：同じ突起を読み替える');duckPath(c);c.fillStyle='#e9e9df';c.fill();c.strokeStyle=C.ink;c.lineWidth=4;c.stroke();circle(c,354,169,6,C.ink);line(c,432,236,417,239,C.ink,3);
    if(s.reveal){const rabbit=val(s)>=.5;line(c,160,103,265,146,C.orange,7);line(c,150,170,255,184,C.orange,7);arrow(c,150,300,200,202,C.orange,3);text(c,rabbit?'耳として読む':'くちばしとして読む',176,330,20,C.orange);text(c,rabbit?'ウサギ →':'← アヒル',415,310,20,C.teal);}
    footer(c,s.reveal?'色の付いた2本の部分が、両方の解釈に使われる。':'原典画像を使わない独自の簡略線画。見え方には個人差。');
  });

  register('M21',(c,s)=>{
    title(c,'階段の上側／下側を読み替える');const A=[[120,260],[120,218],[174,218],[174,176],[228,176],[228,134],[282,134],[282,92],[336,92]],B=A.map(([x,y])=>[x+130,y+65]);
    if(s.reveal){const flip=val(s)>=.5;for(let i=1;i<A.length-1;i+=2){const q=flip?i-1:i;polygon(c,[A[q],A[q+1],B[q+1],B[q]],flip?'#a8c8cc':'#e5b49e',null);}}
    [A,B].forEach(p=>{c.beginPath();p.forEach((q,i)=>i?c.lineTo(...q):c.moveTo(...q));c.lineWidth=3;c.strokeStyle=C.ink;c.stroke();});for(let i=0;i<A.length;i++)line(c,...A[i],...B[i],C.ink,3);
    text(c,'A',96,263,22,C.orange);text(c,'B',489,158,22,C.teal);if(s.reveal)text(c,val(s)<.5?'面の候補を強調':'別の面の候補を強調',430,329,19);
    footer(c,'静止線画の奥行きの多義性。不可能階段とは区別する。');
  });

  register('M22',(c,s)=>{
    title(c,'大きな文字を読む／小さな文字を読む');const step=29+val(s)*10,x0=320-step*3,y0=87;
    for(let y=0;y<7;y++)for(let x=0;x<7;x++)if(x===0||x===6||y===3)text(c,'S',x0+x*step,y0+y*step,26,C.ink);
    if(s.reveal){line(c,x0,y0,x0,y0+6*step,C.orange,3,[5,5]);line(c,x0+6*step,y0,x0+6*step,y0+6*step,C.orange,3,[5,5]);line(c,x0,y0+3*step,x0+6*step,y0+3*step,C.orange,3,[5,5]);circle(c,x0,y0,22,null,C.teal,3);text(c,'全体 H',105,185,21,C.orange);text(c,'部分 S',535,185,21,C.teal);}
    footer(c,'反応時間は測定しない。全体優先は大きさや課題でも変わる。');
  });

  function token(c,i,x,y,r,changed){const k=changed?(i+1)%4:i%4;const color=[C.teal,C.blue,C.orange,'#987b45'][i%4];if(k===0)circle(c,x,y,r,color);else if(k===1)rect(c,x-r,y-r,r*2,r*2,color);else if(k===2)polygon(c,[[x,y-r-1],[x+r+1,y+r],[x-r-1,y+r]],color);else polygon(c,[[x,y-r-2],[x+r+2,y],[x,y+r+2],[x-r-2,y]],color);}
  function shelf(c,x,y,w,h,target,change,highlight){const cw=w/5,ch=h/4;rect(c,x,y,w,h,'#e8edf0',C.pale);for(let j=1;j<4;j++)line(c,x,y+j*ch,x+w,y+j*ch,'#b7c5cf',2);for(let i=0;i<20;i++){const xx=x+(i%5+.5)*cw,yy=y+(Math.floor(i/5)+.5)*ch;token(c,i,xx,yy,Math.min(cw,ch)*.23,change&&i===target);if(highlight&&i===target)circle(c,xx,yy,Math.min(cw,ch)*.4,null,C.orange,3);}}
  register('M23',(c,s)=>{
    title(c,'遮られる前後で、1つの記号が変わる');const target=((s.seed||1)*7+(s.variant||0)*3)%20;
    if(s.reveal){shelf(c,30,91,275,245,target,false,true);shelf(c,335,91,275,245,target,true,true);text(c,'前',167,64,20);text(c,'後',472,64,20);footer(c,'輪で囲んだ1個だけが違う。残る19個の描画は同じ。');return;}
    const d=2.8+val(s)*2.2,t=time(s),n=Math.floor(t/d),q=t%d,mask=Math.min(1,q/.5,(d-q)/.5);shelf(c,85,68,470,270,target,n%2===1,false);
    if(t>0&&mask<1){c.save();c.globalAlpha=1-mask;rect(c,85,68,470,270,'#b8c1c8');c.restore();}
    footer(c,'穏やかな遮蔽を挟む。確認すると2枚を並べて比較できる。');
  });

  register('M24',(c,s)=>{
    title(c,'白い点が中央の線を横切る回数を数える');const t=s.reveal?5:Math.min(time(s),10),rate=.6+.5*val(s);
    rect(c,65,60,510,280,'#26384a');line(c,320,75,320,325,'#7891a5',2,[6,7]);
    for(let i=0;i<4;i++){const x=320+205*Math.sin(t*rate+i*1.65),y=95+i*64;circle(c,x,y,12,'#edf2f4');circle(c,320+190*Math.sin(t*(rate+.2)+i*1.5+1.2),y+27,10,'#5b858f');}
    if(t>=3&&t<=7){const x=95+(t-3)/4*450,y=203;polygon(c,[[x,y-24],[x+24,y],[x,y+24],[x-24,y]],C.orange);if(s.reveal){circle(c,x,y,40,null,'#f2c0a3',3);arrow(c,112,280,530,280,'#f2c0a3',2);}}
    footer(c,s.reveal?'3〜7秒に橙色の菱形が通過。今は5秒の状態を表示。':time(s)>=10?'10秒で終了。確認して別の出来事を振り返る。':'初見の予期を完全には統制できないため、実験ではない。');
  });

  register('M25',(c,s)=>{
    title(c,'左の十字を見たまま、右の文字を意識する');cross(c,112,200,11,C.ink,3);const gap=28+val(s)*42;
    text(c,'R',455,123,34,C.ink);text(c,'R',455,270,34,C.ink);
    if(!s.reveal){text(c,'T',455-gap,270,34,C.ink);text(c,'H',455+gap,270,34,C.ink);}else{circle(c,455,123,29,null,C.orange,2);circle(c,455,270,29,null,C.orange,2);line(c,112,200,455,123,C.pale,2,[5,5]);line(c,112,200,455,270,C.pale,2,[5,5]);}
    footer(c,s.reveal?'上下とも同じR。周囲の文字を取り除いた。':'直接Rへ目を向けると、周辺視の比較ではなくなる。');
  });

  register('M26',(c,s)=>{
    title(c,'機械の部品が、顔に見えることがある');c.save();c.translate(320,200);c.rotate((val(s)-.5)*TAU);
    rect(c,-137,-125,274,250,'#dce3df',C.muted,4);
    [[-69,-48],[69,-48]].forEach(([x,y])=>{circle(c,x,y,31,'#a1b1b2',s.reveal?C.orange:C.ink,3);line(c,x-14,y,x+14,y,C.ink,5);});
    rect(c,-75,47,150,48,s.reveal?'#75a2a0':C.ink);for(let i=-55;i<=55;i+=22)line(c,i,56,i,87,'#cbd7d4',5);c.restore();
    if(s.reveal){text(c,'2つのねじ',118,80,19,C.orange);text(c,'通気口',521,315,19,C.teal);}
    footer(c,s.reveal?'部品の名前を変えても、顔らしい配置は残っている。':'目と口の画像は使わず、部品の配置だけで印象を作る。');
  });

  register('M27',(c,s)=>{
    title(c,'自動運動：固定点と知覚の報告例（模式図）');rect(c,50,82,250,235,'#1d2935');const alpha=s.reveal?1:val(s)*.65;
    c.save();c.globalAlpha=alpha;grid(c,65,97,220,205,25,'#667b8d');c.restore();circle(c,175,200,4,'#b9c3cb');
    rect(c,340,82,250,235,'#e9edf1',C.pale);c.beginPath();c.moveTo(465,200);c.bezierCurveTo(487,169,410,140,426,193);c.bezierCurveTo(440,228,495,250,514,205);c.bezierCurveTo(539,167,467,165,482,218);c.setLineDash([5,6]);c.strokeStyle=C.orange;c.lineWidth=3;c.stroke();c.setLineDash([]);
    text(c,'固定された点',175,341,19);text(c,'知覚されうる軌跡の例',465,341,18);
    if(s.reveal){cross(c,175,200,16,'#e3ac8f');text(c,'位置は一定',175,285,18,'#c8d4df');}
    footer(c,'右の軌跡は説明用。暗室や長時間の凝視は求めない。');
  });

  register('M28',(c,s)=>{
    title(c,'クロノスタシス：時間の伸びの模式図');const start=145,unit=110,stretch=25+val(s)*55;
    text(c,'物理時間',75,126,18);text(c,'主観の例',75,236,18);
    line(c,start,142,585,142,C.ink,2);line(c,start-stretch,272,585,272,C.ink,2);
    for(let i=0;i<4;i++){line(c,start+i*unit,127,start+i*unit,157,C.ink,3);text(c,`${i}秒`,start+i*unit,101,18,C.muted);}
    for(let i=0;i<4;i++){const x=i===0?start-stretch:start+i*unit;line(c,x,257,x,287,C.ink,3);}
    rect(c,start,163,unit,25,'#8bb3b2');rect(c,start-stretch,293,unit+stretch,25,'#dfab8f');text(c,'同じ1秒',start+unit/2,204,19,C.teal);text(c,'最初の区間を長く感じる',305,337,19,C.orange);
    arrow(c,start-stretch,70,start,70,C.orange,2);text(c,'視線移動',80,50,18,C.muted);
    if(s.reveal){line(c,start,115,start,324,C.teal,2,[5,5]);line(c,start+unit,115,start+unit,324,C.teal,2,[5,5]);}
    footer(c,'上段は等間隔。下段の伸びは説明用で、実測値ではない。');
  });

  function grating(c,x,y,r,vertical,color,alpha=1){c.save();c.globalAlpha=alpha;c.beginPath();c.arc(x,y,r,0,TAU);c.clip();rect(c,x-r,y-r,r*2,r*2,'#e2e8ed');for(let d=-r;d<=r;d+=16)vertical?rect(c,x+d,y-r,7,r*2,color):rect(c,x-r,y+d,r*2,7,color);c.restore();}
  register('M29',(c,s)=>{
    title(c,'両眼視野闘争：分離提示の模式図');grating(c,185,132,66,true,C.teal);grating(c,455,132,66,false,C.orange);text(c,'左眼への入力',185,51,19);text(c,'右眼への入力',455,51,19);
    const q=(Math.sin(time(s)*(.35+.35*val(s)))+1)/2;grating(c,320,280,54,true,C.teal);grating(c,320,280,54,false,C.orange,q);
    arrow(c,185,205,268,253,C.muted,2);arrow(c,455,205,372,253,C.muted,2);text(c,'知覚の交替・混合を模した表示',320,350,18);
    if(s.reveal){rect(c,94,66,182,132,null,C.blue,2);rect(c,364,66,182,132,null,C.blue,2);text(c,'同時に一定',110,298,18,C.blue);text(c,'入力は変えない',524,298,18,C.blue);}
    footer(c,'左右眼へ実際には分離しない。下段の変化は模式アニメ。');
  });

  register('M30',(c,s)=>{
    title(c,'ランダムドット：左右の対応の模式図');const N=28,cell=7,xs=[72,372],y=92,shift=1+Math.round(val(s)*2),seed=s.seed||7;
    const bit=(x,y,extra=0)=>rand(y*53+x,seed+extra)>.5;
    for(let side=0;side<2;side++)for(let yy=0;yy<N;yy++)for(let xx=0;xx<N;xx++){
      let sx=xx,extra=0;
      if(side===1&&yy>=8&&yy<20){if(xx>=8+shift&&xx<20+shift)sx=xx-shift;else if(xx>=8&&xx<8+shift)extra=31;}
      const b=bit(sx,yy,extra);rect(c,xs[side]+xx*cell,y+yy*cell,cell,cell,b?'#334854':'#e8edef');
    }
    text(c,'左眼用の画像',170,63,19);text(c,'右眼用の画像',470,63,19);
    if(s.reveal){rect(c,xs[0]+56,y+56,84,84,null,C.orange,3);rect(c,xs[1]+56+shift*cell,y+56,84,84,null,C.orange,3);const yy=y+12.5*cell,xx=xs[0]+12.5*cell,xx2=xs[1]+(12.5+shift)*cell;circle(c,xx,yy,7,C.orange);circle(c,xx2,yy,7,C.orange);line(c,xx,yy,xx2,yy,C.orange,2,[4,5]);text(c,`中央だけ ${shift*cell} px の対応ずれ`,320,328,20,C.orange);}
    else text(c,'この画面は左右眼へ分離していない',320,328,19,C.muted);
    footer(c,'確認で対応を可視化。無理な裸眼立体視を求めない。');
  });

  register('M31',(c,s)=>{
    title(c,'プルフリッヒ効果：時間差 → 位置差（模式図）');const t=time(s)+.8,delay=.1+.4*val(s),x=320+175*Math.sin(t*.85),old=320+175*Math.sin((t-delay)*.85);
    line(c,120,102,520,102,C.pale,3);circle(c,x,102,12,C.ink);text(c,'平面上の物体',84,72,18,C.ink,'left');
    line(c,120,181,520,181,C.pale,2);line(c,120,241,520,241,C.pale,2);circle(c,x,181,11,C.teal);circle(c,old,241,11,C.orange);text(c,'先の信号',92,181,18,C.teal,'right');text(c,'遅れた信号',92,241,18,C.orange,'right');
    if(s.reveal){line(c,x,117,x,258,C.teal,2,[4,4]);line(c,old,223,old,258,C.orange,2,[4,4]);arrow(c,old,270,x,270,C.orange,2);}
    c.beginPath();c.ellipse(320,318,134,18,0,0,TAU);c.strokeStyle=C.muted;c.lineWidth=2;c.setLineDash([5,5]);c.stroke();c.setLineDash([]);circle(c,320+134*Math.sin(t*.85),318+18*Math.cos(t*.85),6,C.blue);text(c,'奥行き軌道の知覚例',320,352,18,C.muted);
    footer(c,'模式図。眼ごとの減光や立体提示は行っていない。');
  });

  function lattice(c,x,y,w,h,ang,which=2){c.save();c.beginPath();c.rect(x,y,w,h);c.clip();rect(c,x,y,w,h,'#e5ebeb');c.translate(x+w/2,y+h/2);for(let layer=0;layer<2;layer++){if(which<2&&layer!==which)continue;c.save();c.rotate(layer?ang:0);c.strokeStyle=layer?'#507d81':'#52636d';c.lineWidth=2;for(let a=-550;a<550;a+=9){c.beginPath();c.moveTo(a,-500);c.lineTo(a,500);c.stroke();}c.restore();}c.restore();}
  register('M32',(c,s)=>{
    title(c,'2枚の格子から現れる大きな縞');const a=(1+val(s)*13)*PI/180;
    if(s.reveal){lattice(c,22,95,184,235,a,0);lattice(c,228,95,184,235,a,1);lattice(c,434,95,184,235,a,2);text(c,'格子 A',114,65,20);text(c,'格子 B',320,65,20);text(c,'重ね合わせ',526,65,20);}
    else lattice(c,70,61,500,285,a,2);
    footer(c,s.reveal?'大きな縞は重ね合わせで生じる。両眼視は必要ない。':`格子の角度差 ${(a*180/PI).toFixed(1)}°。静止した2枚の直線群。`);
  });

  Object.assign(window.ILLUSION_RENDERERS || (window.ILLUSION_RENDERERS = {}), R);
})();
