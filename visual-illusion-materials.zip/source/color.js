(function () {
  'use strict';
  const W = 640, H = 400, INK = '#253044', MUTED = '#56627a';
  const TAU = Math.PI * 2;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const rgb = (r, g, b) => `rgb(${Math.round(r)},${Math.round(g)},${Math.round(b)})`;
  const gray = v => rgb(v, v, v);
  const mix = (a, b, t) => a.map((v, i) => Math.round(v + (b[i] - v) * t));
  function rect(c, x, y, w, h, color) { c.fillStyle = color; c.fillRect(x, y, w, h); }
  function circle(c, x, y, r, color) {
    c.fillStyle = color; c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill();
  }
  function ring(c, x, y, r, color, width = 2) {
    c.strokeStyle = color; c.lineWidth = width; c.beginPath(); c.arc(x, y, r, 0, TAU); c.stroke();
  }
  function line(c, x1, y1, x2, y2, color = INK, width = 2) {
    c.strokeStyle = color; c.lineWidth = width; c.beginPath(); c.moveTo(x1, y1); c.lineTo(x2, y2); c.stroke();
  }
  function text(c, str, x, y, size = 20, color = INK, align = 'left') {
    c.font = `${size}px "Noto Sans JP", "Yu Gothic", sans-serif`;
    c.fillStyle = color; c.textAlign = align; c.textBaseline = 'middle'; c.fillText(str, x, y);
  }
  function wrap(c, str, x, y, width, size = 18, color = MUTED, leading = 27) {
    c.font = `${size}px "Noto Sans JP", "Yu Gothic", sans-serif`;
    let row = '', yy = y;
    for (const char of str) {
      if (char === '\n' || (row && c.measureText(row + char).width > width)) {
        text(c, row, x, yy, size, color); row = char === '\n' ? '' : char; yy += leading;
      } else row += char;
    }
    if (row) text(c, row, x, yy, size, color);
  }
  function cross(c, x, y, size = 10, color = INK, width = 3) {
    line(c, x - size, y, x + size, y, color, width);
    line(c, x, y - size, x, y + size, color, width);
  }
  function arrow(c, x1, y1, x2, y2, color = MUTED, width = 2) {
    line(c, x1, y1, x2, y2, color, width);
    const a = Math.atan2(y2 - y1, x2 - x1);
    line(c, x2, y2, x2 - 10 * Math.cos(a - .45), y2 - 10 * Math.sin(a - .45), color, width);
    line(c, x2, y2, x2 - 10 * Math.cos(a + .45), y2 - 10 * Math.sin(a + .45), color, width);
  }
  function frame(c, x, y, w, h, color = '#9ca7b6', width = 1.5) {
    c.strokeStyle = color; c.lineWidth = width; c.strokeRect(x, y, w, h);
  }
  function heading(c, str, color = INK) { text(c, str, W / 2, 29, 22, color, 'center'); }
  function footer(c, str, color = MUTED) { text(c, str, W / 2, 374, 18, color, 'center'); }
  function background(c, color = '#ffffff') { rect(c, 0, 0, W, H, color); }
  const renderers = {};

  renderers.C01 = function (c, s) {
    background(c, '#f6f7fa'); heading(c, s.reveal ? '背景をそろえると？' : '中央の2枚を比べる');
    const v = s.value, low = 112 - 100 * v, high = 144 + 100 * v;
    rect(c, 35, 70, 280, 258, s.reveal ? '#b4b4b4' : gray(low));
    rect(c, 325, 70, 280, 258, s.reveal ? '#b4b4b4' : gray(high));
    if (s.reveal) rect(c, 175, 187, 290, 24, '#808080');
    rect(c, 130, 154, 90, 90, '#808080'); rect(c, 420, 154, 90, 90, '#808080');
    footer(c, s.reveal ? '両方とも RGB (128, 128, 128)' : '描画色は同じ。違うのは周囲の明暗。');
  };

  renderers.C02 = function (c, s) {
    background(c, '#f4f5f7'); heading(c, s.reveal ? '文脈を外して A と B を比較' : '影の外の A ／ 影の中の B');
    const x = 80, y = 78, size = 64, ax = x + size, ay = y, bx = x + size * 4, by = y + size * 2;
    if (!s.reveal) {
      for (let r = 0; r < 4; r++) for (let col = 0; col < 6; col++)
        rect(c, x + col * size, y + r * size, size, size, (r + col) % 2 ? '#8a8a8a' : '#e4e4e4');
      c.save(); c.beginPath(); c.rect(x, y, 384, 256); c.clip();
      c.fillStyle = 'rgba(0,0,0,.4)'; c.beginPath();
      c.moveTo(405, 87); c.lineTo(464, 110); c.lineTo(448, 334); c.lineTo(244, 334); c.closePath(); c.fill(); c.restore();
      // Deliberate equal-RGB target; the surrounding shadow is a separate layer.
      rect(c, bx, by, size, size, '#8a8a8a');
      const gr = c.createLinearGradient(427, 0, 493, 0);
      gr.addColorStop(0, '#50775a'); gr.addColorStop(.5, '#88ad86'); gr.addColorStop(1, '#385b43');
      rect(c, 427, 76, 66, 100, gr);
      c.fillStyle = '#a2b99c'; c.beginPath(); c.ellipse(460, 76, 33, 14, 0, 0, TAU); c.fill();
      c.fillStyle = '#507256'; c.beginPath(); c.ellipse(460, 176, 33, 14, 0, 0, Math.PI); c.fill();
    } else {
      rect(c, 60, 60, 520, 286, '#c5c5c5');
      rect(c, ax, ay, size, size, '#8a8a8a'); rect(c, bx, by, size, size, '#8a8a8a');
      text(c, '同じ塗りを取り出す', 320, 310, 20, INK, 'center');
    }
    text(c, 'A', ax + size / 2, ay + size / 2, 22, '#111111', 'center');
    text(c, 'B', bx + size / 2, by + size / 2, 22, '#111111', 'center');
    footer(c, s.reveal ? 'A・B の面は RGB (138, 138, 138)' : '照明と表面を分けて読むための、独自の簡略作図');
  };

  function stripedTargets(c, s, chromatic) {
    background(c, '#f7f8fa'); heading(c, s.reveal ? '縞を取り除いた状態' : chromatic ? '同じ緑が、違う色調に見える？' : '縞の中の同じ灰色');
    const h = Math.round(14 + s.value * 20), top = 76, bottom = 328;
    const leftX = 166, rightX = 398, target = chromatic ? '#65cba6' : '#969696';
    c.save(); c.beginPath(); c.rect(60, top, 520, bottom - top); c.clip();
    if (s.reveal) rect(c, 60, top, 520, bottom - top, '#dddddd');
    for (let i = 0, yy = top; yy < bottom; yy += h, i++) {
      if (!s.reveal) rect(c, 60, yy, 520, h, chromatic ? (i % 2 ? '#eb7eb0' : '#445cc6') : (i % 2 ? '#ffffff' : '#141414'));
      rect(c, i % 2 ? rightX : leftX, yy, 76, h, target);
    }
    c.restore();
    footer(c, s.reveal ? (chromatic ? '緑の断片はすべて RGB (101, 203, 166)' : '灰色の断片はすべて RGB (150, 150, 150)') : '縞の太さでも見え方が変わる');
  }
  renderers.C03 = (c, s) => stripedTargets(c, s, false);

  renderers.C04 = function (c, s) {
    background(c, '#f5f6f8'); heading(c, '勾配の端に、明るい帯・暗い帯が見える？');
    const ramp = Math.round(90 + 230 * s.value), x1 = Math.round(320 - ramp / 2), x2 = x1 + ramp;
    const yy = 76, hh = s.reveal ? 156 : 230;
    rect(c, 60, yy, x1 - 60, hh, '#404040');
    const g = c.createLinearGradient(x1, 0, x2, 0); g.addColorStop(0, '#404040'); g.addColorStop(1, '#cccccc');
    rect(c, x1, yy, x2 - x1, hh, g); rect(c, x2, yy, 580 - x2, hh, '#cccccc');
    if (s.reveal) {
      text(c, 'RGB描画値の断面（輝度の実測ではない）', 320, 262, 18, MUTED, 'center');
      line(c, 60, 342, 580, 342, '#a6adba', 1);
      line(c, 60, 326, x1, 326, '#258366', 3); line(c, x1, 326, x2, 292, '#258366', 3); line(c, x2, 292, 580, 292, '#258366', 3);
      text(c, '64', 66, 306, 18, INK); text(c, '204', 568, 277, 18, INK, 'right');
      c.save(); c.setLineDash([5, 5]); line(c, x1, 238, x1, 342, '#95a1b2', 1); line(c, x2, 238, x2, 342, '#95a1b2', 1); c.restore();
    }
    footer(c, s.reveal ? '余分なピークを描かず、平坦 → 増加 → 平坦' : '明暗の勾配の幅を変えて比較する');
  };

  renderers.C05 = function (c, s) {
    background(c, '#f7f8fb'); heading(c, s.reveal ? '黒い区画を外した状態' : '周辺の交差点を観察');
    const street = 9 + Math.round(s.value * 15);
    rect(c, 55, 64, 530, 276, s.reveal ? '#ffffff' : '#101010');
    if (!s.reveal) {
      for (let x = 85; x <= 565; x += 60) rect(c, x - street / 2, 64, street, 276, '#ffffff');
      for (let y = 82; y <= 322; y += 60) rect(c, 55, y - street / 2, 530, street, '#ffffff');
    } else {
      frame(c, 55, 64, 530, 276, '#c7cdd6');
      frame(c, 150, 150, 90, 90, '#a6adba'); frame(c, 400, 150, 90, 90, '#a6adba');
      text(c, '交差点の白', 195, 275, 20, INK, 'center'); text(c, '道路の白', 445, 275, 20, INK, 'center');
    }
    footer(c, s.reveal ? 'どちらも RGB (255, 255, 255)' : '暗い斑点は描いていません。画像は静止しています。');
  };

  renderers.C06 = function (c, s) {
    background(c, '#f7f8fb'); heading(c, s.reveal ? '格子を外して白い円だけに' : '白い点の中に、黒い点が見える？');
    rect(c, 55, 62, 530, 280, s.reveal ? '#6e7787' : '#101010');
    if (!s.reveal) {
      for (let i = 0; i < 7; i++) rect(c, 110 + i * 70 - 6, 62, 12, 280, '#8f8f8f');
      for (let i = 0; i < 4; i++) rect(c, 55, 95 + i * 70 - 6, 530, 12, '#8f8f8f');
    }
    for (let row = 0; row < 4; row++) for (let col = 0; col < 7; col++) circle(c, 110 + col * 70, 95 + row * 70, 9, '#ffffff');
    footer(c, s.reveal ? '28個の白い円。黒い点を描く処理はありません。' : '動いているのは画像ではなく、見えの印象です。');
  };

  renderers.C07 = function (c, s) {
    background(c, '#f6f7f9'); heading(c, s.reveal ? '中央の勾配だけを隠す' : '中央から離れた左右の面を比較');
    rect(c, 60, 78, 520, 244, '#969696');
    const depth = 8 + 36 * s.value;
    if (!s.reveal) {
      const a = c.createLinearGradient(284, 0, 320, 0); a.addColorStop(0, gray(150)); a.addColorStop(1, gray(150 - depth));
      const b = c.createLinearGradient(320, 0, 356, 0); b.addColorStop(0, gray(150 + depth)); b.addColorStop(1, gray(150));
      rect(c, 284, 78, 36, 244, a); rect(c, 320, 78, 36, 244, b);
    } else {
      rect(c, 281, 65, 78, 270, '#f6f7f9');
      text(c, '左の面', 170, 200, 20, '#ffffff', 'center'); text(c, '右の面', 470, 200, 20, '#ffffff', 'center');
    }
    footer(c, s.reveal ? '左右の広い面は RGB (150, 150, 150)' : '実際の明暗差は中央72pxの範囲だけ');
  };

  function wavyLoop(c, cx, cy, rx, ry, inset, color, width) {
    c.strokeStyle = color; c.lineWidth = width; c.lineJoin = 'round'; c.beginPath();
    for (let j = 0; j <= 240; j++) {
      const a = j / 240 * TAU, r = 3.2 * Math.sin(12 * a);
      const x = cx + (rx - inset + r) * Math.cos(a), y = cy + (ry - inset + r) * Math.sin(a);
      if (j === 0) c.moveTo(x, y); else c.lineTo(x, y);
    }
    c.closePath(); c.stroke();
  }
  renderers.C08 = function (c, s) {
    background(c); heading(c, s.reveal ? '紫の外側輪郭を外した状態' : '白い内部が、薄く橙色に見える？');
    const width = 2.5 + s.value * 2.5;
    if (!s.reveal) wavyLoop(c, 175, 202, 109, 99, 0, '#713a9b', width);
    wavyLoop(c, 175, 202, 109, 99, width, '#ed9a35', width);
    wavyLoop(c, 465, 202, 109, 99, width, '#ed9a35', width);
    text(c, s.reveal ? '橙の輪郭だけ' : '紫＋内側の橙', 175, 333, 20, INK, 'center');
    text(c, '橙の輪郭だけ', 465, 333, 20, INK, 'center');
    footer(c, '両方の内部に、色付きの面は塗っていません。');
  };

  renderers.C09 = function (c, s) {
    background(c); heading(c, s.reveal ? '外側の黒い線だけを外す' : '色の線の間に、薄い面が見える？');
    const cx = 320, cy = 204;
    for (let i = 0; i < 12; i++) {
      const a = i / 12 * TAU;
      line(c, cx, cy, cx + 71 * Math.cos(a), cy + 71 * Math.sin(a), '#169ec2', 4);
      if (!s.reveal) line(c, cx + 71 * Math.cos(a), cy + 71 * Math.sin(a), cx + 143 * Math.cos(a), cy + 143 * Math.sin(a), '#151515', 4);
    }
    footer(c, '色付きなのは細線だけ。線の間は白です。');
  };
  renderers.C10 = (c, s) => stripedTargets(c, s, true);

  renderers.C11 = function (c, s) {
    background(c, '#f7f8fa'); heading(c, s.reveal ? '背景の色を取り除く' : '同じ灰色に、色味がついて見える？');
    const a = mix([185, 185, 185], [224, 82, 98], s.value), b = mix([185, 185, 185], [68, 185, 197], s.value);
    rect(c, 35, 70, 280, 260, s.reveal ? '#c4c4c4' : rgb(...a));
    rect(c, 325, 70, 280, 260, s.reveal ? '#c4c4c4' : rgb(...b));
    rect(c, 130, 155, 90, 90, '#a0a0a0'); rect(c, 420, 155, 90, 90, '#a0a0a0');
    footer(c, '中央2枚は RGB (160, 160, 160)');
  };

  renderers.C12 = function (c, s) {
    background(c, '#f4f5f8'); heading(c, s.reveal ? 'カードを中立背景に取り出す' : '照明色の違いを模した2つの場面');
    const amt = .35 + s.value * .65;
    const warm = mix([232, 232, 232], [250, 219, 186], amt), cool = mix([232, 232, 232], [186, 219, 250], amt);
    const scenes = [{cx:165,tint:[255,200,143],card:warm,name:'暖色の照明'}, {cx:475,tint:[143,200,255],card:cool,name:'寒色の照明'}];
    for (const d of scenes) {
      const x = d.cx - 135;
      if (!s.reveal) {
        rect(c, x, 72, 270, 255, rgb(...mix([214, 214, 214], d.tint, .28 + .3 * s.value)));
        rect(c, x + 15, 227, 240, 83, rgb(...mix([153, 153, 153], d.tint, .15)));
        const colors = [[125, 87, 59], [48, 111, 127], [130, 74, 108]];
        colors.forEach((col, i) => rect(c, x + 19 + i * 80, 245, 65, 45, rgb(...mix(col, d.tint, .2))));
        rect(c, d.cx - 40, 118, 102, 126, rgb(...mix([100,100,100], d.tint, .15)));
      }
      rect(c, d.cx - 51, 106, 102, 126, rgb(...d.card));
      if (s.reveal) frame(c, d.cx - 51, 106, 102, 126, '#c0c5cf');
      text(c, d.name, d.cx, 350, 20, INK, 'center');
      if (s.reveal) { text(c, `RGB (${d.card.join(', ')})`, d.cx, 273, 18, INK, 'center'); text(c, '同じ形・異なる描画色', d.cx, 303, 18, MUTED, 'center'); }
    }
    footer(c, '照明と色恒常性の模式図。物理的な照明実験ではありません。');
  };

  renderers.C13 = function (c, s) {
    // No inducer before manual play, while paused, or after the first eight seconds.
    background(c, '#b0b0b0');
    const inducing = s.running && s.time < 8 && !s.reveal;
    const initial = s.time === 0 && !s.running && !s.reveal;
    if (inducing) circle(c, 320, 195, 70, '#c84bb4');
    if (initial) { ring(c, 320, 195, 70, '#858585', 2); text(c, '開始前：輪郭だけ', 320, 300, 20, '#303030', 'center'); }
    cross(c, 320, 195, 8, '#222222', 3);
    heading(c, inducing ? `中心の＋を見る　残り ${Math.max(1, Math.ceil(8 - s.time))} 秒` : initial ? '再生で開始：色の提示は最大8秒' : '今は灰色だけを表示しています', '#292929');
    if (s.reveal) {
      frame(c, 232, 107, 176, 176, '#6c6c6c', 1);
      text(c, '円の場所も RGB (176, 176, 176)', 320, 322, 20, '#292929', 'center');
    }
    if (inducing) { rect(c, 120, 333, 400, 6, '#969696'); rect(c, 120, 333, 400 * clamp(s.time / 8, 0, 1), 6, '#5e5e5e'); }
    footer(c, inducing ? '停止すると色の提示を終了します。' : '緑の円は描いていません。見えない場合もあります。', '#353535');
  };

  renderers.C14 = function (c, s) {
    background(c, '#bcbcbc'); heading(c, '中心の＋を見て、薄い周辺の斑点を観察', '#343434');
    const alpha = .11 + .38 * s.value;
    for (let i = 0; i < 12; i++) {
      const a = i / 12 * TAU, x = 320 + 164 * Math.cos(a), y = 207 + 118 * Math.sin(a);
      const g = c.createRadialGradient(x, y, 0, x, y, 24);
      g.addColorStop(0, `rgba(162,91,169,${alpha})`); g.addColorStop(.55, `rgba(162,91,169,${alpha * .6})`); g.addColorStop(1, 'rgba(162,91,169,0)');
      circle(c, x, y, 24, g);
      if (s.reveal) ring(c, x, y, 26, '#626875', 2);
    }
    cross(c, 320, 207, 9, '#303030', 3);
    footer(c, s.reveal ? '輪郭を加えて位置を確認。斑点は残っています。' : 'プログラムによる消去やフェードはありません。', '#343434');
  };

  renderers.C15 = function (c, s) {
    background(c); heading(c, '左目を閉じ、右目で左の＋を見る');
    const x = 170 + 180 + 100 * s.value;
    cross(c, 170, 195, 13, '#121212', 4); circle(c, x, 212, 13, '#121212');
    if (s.reveal) {
      c.save(); c.setLineDash([6, 5]); frame(c, x - 32, 180, 64, 64, '#7f8fa6', 2); c.restore();
      arrow(c, x + 56, 130, x + 9, 181, '#5c6b82', 2);
      text(c, '点はここに残る', 420, 103, 20, INK, 'center');
      line(c, 170, 280, x, 280, '#8d98a8', 1.5);
      line(c, 170, 272, 170, 288, '#8d98a8', 1.5); line(c, x, 272, x, 288, '#8d98a8', 1.5);
    }
    text(c, '注視する', 170, 315, 20, INK, 'center'); text(c, '直接見ない', x, 315, 20, INK, 'center');
    footer(c, '無理のない距離で調整。画面の点を消す処理はありません。');
  };

  renderers.C16 = function (c, s) {
    background(c); heading(c, '白い切れ目が盲点に入ると、線は続く？');
    cross(c, 170, 195, 13, '#121212', 4);
    rect(c, 315, 197, 265, 30, '#267cad');
    const gap = 26 + s.value * 52, gx = 425 - gap / 2;
    rect(c, gx, 186, gap, 52, '#ffffff');
    if (s.reveal) {
      c.save(); c.setLineDash([5,5]); frame(c, gx, 185, gap, 54, '#ce763b', 2); c.restore();
      arrow(c, 425, 119, 425, 180, '#ce763b', 2);
      text(c, '実際の白い切れ目', 425, 98, 20, INK, 'center');
      text(c, '左右の帯だけを描画', 425, 290, 20, INK, 'center');
    }
    text(c, '右目で＋を注視', 170, 316, 20, INK, 'center');
    footer(c, '左目を閉じ、C15と同じ距離の調整を使います。');
  };

  function pacman(c, x, y, radius, middle, half, rotation) {
    circle(c, x, y, radius, '#161616');
    c.fillStyle = '#ffffff'; c.beginPath(); c.moveTo(x, y);
    c.arc(x, y, radius + 1, middle - half + rotation, middle + half + rotation); c.closePath(); c.fill();
  }
  renderers.C17 = function (c, s) {
    background(c); heading(c, s.reveal ? '切り口を外向きに回す' : '中央に、白い三角形が見える？');
    const points = [[320,99],[174,292],[466,292]], rot = s.reveal ? Math.PI : (s.value - .5) * Math.PI;
    points.forEach((p, i) => {
      const others = points.filter((_, j) => i !== j);
      const aa = others.map(q => Math.atan2(q[1] - p[1], q[0] - p[0]));
      const mid = Math.atan2(Math.sin(aa[0]) + Math.sin(aa[1]), Math.cos(aa[0]) + Math.cos(aa[1]));
      const half = Math.acos(clamp(Math.cos(aa[0] - aa[1]), -1, 1)) / 2;
      pacman(c, p[0], p[1], 47, mid, half, rot);
    });
    footer(c, '描いているのは欠けた3つの円。中央の辺は描いていません。');
  };

  renderers.C18 = function (c, s) {
    background(c, '#f5f6f8'); heading(c, s.reveal ? '遮蔽物を外して、実際の形を確認' : '板の後ろで、1つの円につながる？');
    circle(c, 320, 201, 105, '#de9140');
    const broken = s.variant % 2 !== 0;
    if (broken) rect(c, 282, 88, 76, 226, '#f5f6f8');
    const moving = s.time > 0 ? 135 * (1 - Math.cos(Math.min(s.time, 20) * .6)) / 2 : 0;
    const panelX = s.reveal ? 500 : 270 + (s.value - .5) * 260 + moving;
    rect(c, panelX, 77, 100, 248, '#5b6f8a');
    line(c, panelX + 2, 77, panelX + 2, 325, '#d4dbe4', 3);
    if (s.reveal) {
      text(c, broken ? '中央が切れている' : '完全な円', 320, 337, 20, INK, 'center');
      text(c, '板', 550, 201, 20, '#ffffff', 'center');
    }
    footer(c, s.reveal ? '別条件では、見えなかった中央の形が変わります。' : '隠れた部分の形は、初期像だけでは一意に決まりません。');
  };

  renderers.C19 = function (c, s) {
    background(c); heading(c, s.reveal ? '本当の細い円周を加えた状態' : '線の端が、明るい円盤を作る？');
    const n = 4 + 4 * Math.round(s.value * 2);
    for (const [cx,cy] of [[205,139],[435,139],[205,281],[435,281]]) {
      for (let i = 0; i < n; i++) {
        const a = i / n * TAU;
        line(c, cx + 25 * Math.cos(a), cy + 25 * Math.sin(a), cx + 60 * Math.cos(a), cy + 60 * Math.sin(a), '#191919', 3);
      }
      if (s.reveal) ring(c, cx, cy, 25, '#191919', 1.5);
    }
    footer(c, '中心も外側も同じ白。明るい面は加えていません。');
  };

  renderers.C20 = function (c, s) {
    background(c, '#f4f6fa'); heading(c, '色順応の概念図：色の変化は描画による説明');
    const t = s.time > 0 ? clamp(s.time / 7, 0, 1) : s.value;
    const input = [222,160,124], output = mix(input, [186,186,186], t);
    text(c, '色の偏った入力', 132, 82, 20, INK, 'center');
    text(c, '中立へ近づくモデル', 505, 82, 20, INK, 'center');
    rect(c, 60, 112, 145, 140, rgb(...input)); rect(c, 432, 112, 145, 140, rgb(...output));
    arrow(c, 219, 183, 268, 183, '#6f7f95', 3); arrow(c, 372, 183, 421, 183, '#6f7f95', 3);
    circle(c, 320, 183, 43, '#e4eaf2');
    text(c, '応答の', 320, 169, 19, INK, 'center'); text(c, '再調整', 320, 196, 19, INK, 'center');
    if (s.reveal) {
      text(c, `RGB ${input.join(', ')}`, 132, 281, 18, INK, 'center'); text(c, `RGB ${output.join(', ')}`, 505, 281, 18, INK, 'center');
      rect(c, 238, 298, 68, 35, rgb(...input)); rect(c, 334, 298, 68, 35, rgb(...output));
      frame(c, 238, 298, 68, 35, '#8f9caf'); frame(c, 334, 298, 68, 35, '#8f9caf');
      text(c, '入力', 272, 347, 18, MUTED, 'center'); text(c, '出力', 368, 347, 18, MUTED, 'center');
    } else {
      text(c, 'RGB補間の説明モデル', 320, 288, 20, INK, 'center');
      text(c, '観察者の順応を測定していません', 320, 325, 20, MUTED, 'center');
    }
    footer(c, '時間的な順応の考え方。実際の順応速度や量の再現ではありません。');
  };

  renderers.C21 = function (c, s) {
    const bg = Math.round(8 + Math.pow(s.value, 3) * 230), lightInk = bg < 110 ? '#eef2f8' : '#202a3a';
    background(c, gray(bg)); heading(c, s.reveal ? '色をそろえ、位置と大きさを確認' : '赤と青の輪が、前後に離れて見える？', lightInk);
    const mono = bg < 110 ? '#bcbcbc' : '#545454';
    for (let row = 0; row < 2; row++) for (let i = 0; i < 5; i++) {
      ring(c, 112 + i * 104, 138 + row * 126, 36, s.reveal ? mono : (i + row) % 2 ? '#244af0' : '#f12637', 10);
      if (s.reveal) { line(c, 104 + i * 104, 138 + row * 126, 120 + i * 104, 138 + row * 126, lightInk, 1); line(c, 112 + i * 104, 130 + row * 126, 112 + i * 104, 146 + row * 126, lightInk, 1); }
    }
    footer(c, s.reveal ? 'すべて半径36。影・立体変換・左右眼用画像なし。' : '背景や片目で見え方が変わることがあります。個人差あり。', lightInk);
  };

  function benhamDisk(c, cx, cy, angle) {
    c.save(); c.translate(cx, cy); c.rotate(angle);
    circle(c, 0, 0, 133, '#ffffff');
    c.fillStyle = '#141414'; c.beginPath(); c.moveTo(0,0); c.arc(0,0,133,Math.PI / 2,Math.PI * 1.5); c.closePath(); c.fill();
    for (let group = 0; group < 4; group++) for (let j = 0; j < 3; j++) {
      c.strokeStyle = '#141414'; c.lineWidth = 5; c.beginPath();
      c.arc(0,0,26 + group * 24 + j * 8, -Math.PI / 2 + group * Math.PI / 4 + .06, -Math.PI / 2 + (group + 1) * Math.PI / 4 - .06); c.stroke();
    }
    ring(c, 0, 0, 133, '#6c6c6c', 2); c.restore();
  }
  renderers.C22 = function (c, s) {
    background(c, '#f4f4f4'); heading(c, 'ベンハム型円盤：構造だけを低速で示す');
    const angle = s.reveal ? 0 : s.value * TAU + s.time * .12;
    benhamDisk(c, 212, 205, angle);
    text(c, '白黒の配置', 462, 93, 22, INK, 'center');
    wrap(c, '適切な時間変化では主観色が生じることがあります。', 380, 137, 225, 20, INK, 30);
    if (s.reveal) {
      rect(c, 402, 235, 60, 58, '#ffffff'); frame(c, 402, 235, 60, 58, '#9b9b9b'); rect(c, 490, 235, 60, 58, '#141414');
      text(c, 'R = G = B', 475, 318, 20, INK, 'center');
    } else wrap(c, 'この再生は低速です。色を誘発する実演は行いません。', 380, 245, 225, 20, MUTED, 30);
    footer(c, '高速回転やフリッカーを使わない模式図です。');
  };

  function grating(c, x, y, w, h, vertical) {
    rect(c, x, y, w, h, '#ffffff');
    c.save(); c.beginPath(); c.rect(x,y,w,h); c.clip();
    if (vertical) { for (let xx = x; xx < x+w; xx+=24) rect(c,xx,y,12,h,'#111111'); }
    else { for (let yy = y; yy < y+h; yy+=24) rect(c,x,yy,w,12,'#111111'); }
    c.restore(); frame(c,x,y,w,h,'#8b95a6',1);
  }
  renderers.C23 = function (c, s) {
    background(c, '#f5f6f9'); heading(c, 'マッカロー効果：向きと色の結び付きの模式図');
    text(c, '縦のテスト縞', 175, 79, 20, INK, 'center'); text(c, '横のテスト縞', 465, 79, 20, INK, 'center');
    grating(c, 103, 107, 144, 130, true); grating(c, 393, 107, 144, 130, false);
    if (s.reveal) {
      rect(c, 160, 281, 70, 47, '#ffffff'); frame(c,160,281,70,47,'#8b95a6'); rect(c, 410, 281, 70, 47, '#111111');
      text(c, '白：255,255,255', 195, 348, 18, INK, 'center'); text(c, '黒：17,17,17', 445, 348, 18, INK, 'center');
    } else {
      arrow(c, 175, 250, 175, 283, '#7b899d', 2); arrow(c, 465, 250, 465, 283, '#7b899d', 2);
      circle(c, 142, 309, 15, '#80bcae'); circle(c, 432, 309, 15, '#c48db3');
      text(c, '残効色の例', 167, 310, 19, INK); text(c, '残効色の例', 457, 310, 19, INK);
      text(c, '色チップは説明用。実際の残効ではありません。', 320, 348, 18, MUTED, 'center');
    }
    footer(c, '誘導用の色付き縞や、長時間の交互提示は行いません。');
  };

  renderers.C24 = function (c, s) {
    background(c, '#f5f7fa'); heading(c, '波長への感度の重みが変わる：定性的な模式図');
    const p = s.time > 0 ? clamp(s.time / 8, 0, 1) : s.value;
    const darkColor = '#277f91', lightColor = '#ac792d';
    text(c, '暗所寄り：桿体系', 185, 70, 20, darkColor, 'center'); text(c, '明所寄り：錐体系', 465, 70, 20, lightColor, 'center');
    line(c, 76, 305, 580, 305, '#8491a4', 2); arrow(c, 76, 305, 76, 102, '#8491a4', 2);
    text(c, '感度', 42, 112, 18, MUTED, 'center');
    function curve(center, width, color, opacity) {
      c.save(); c.globalAlpha = opacity; c.strokeStyle = color; c.lineWidth = 4; c.beginPath();
      for (let x = 90; x <= 570; x+=2) { const y = 305 - 182 * Math.exp(-.5 * Math.pow((x-center)/width,2)); if (x===90)c.moveTo(x,y);else c.lineTo(x,y); }
      c.stroke(); c.restore();
    }
    curve(274,70,darkColor,s.reveal ? 1 : .25 + .75*p); curve(352,80,lightColor,s.reveal ? 1 : 1-.75*p);
    if (s.reveal) {
      c.save(); c.setLineDash([5,5]); line(c,274,123,274,305,darkColor,1.5); line(c,352,123,352,305,lightColor,1.5); c.restore();
      arrow(c, 344, 100, 282, 100, '#6c7789', 2);
    }
    text(c, '短波長寄り', 133, 332, 18, MUTED, 'center'); text(c, '長波長寄り', 524, 332, 18, MUTED, 'center');
    footer(c, '曲線は測定値ではありません。画面上で暗順応を起こす実験なし。');
  };

  const safe = {};
  for (const [id, draw] of Object.entries(renderers)) {
    safe[id] = function (ctx, state) {
      const input = state || {};
      const s = { reveal: !!input.reveal, running: !!input.running,
        time: Math.max(0, Number.isFinite(input.time) ? input.time : 0),
        value: clamp(Number.isFinite(input.value) ? input.value : .5, 0, 1),
        variant: Number.isFinite(input.variant) ? Math.floor(input.variant) : 0,
        seed: Number.isFinite(input.seed) ? input.seed : 0 };
      ctx.save();
      try { ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over'; ctx.setLineDash([]); draw(ctx, s); }
      finally { ctx.restore(); }
    };
  }
  Object.assign(window.ILLUSION_RENDERERS || (window.ILLUSION_RENDERERS = {}), safe);
})();
