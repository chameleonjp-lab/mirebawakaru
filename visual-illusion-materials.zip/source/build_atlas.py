from pathlib import Path
import json
import re
import sys
from collections import Counter

WORK = Path(__file__).resolve().parent
ROOT = WORK.parent
OUT = ROOT / 'output'
OUT.mkdir(exist_ok=True)
CATEGORIES = [
 {'id':'size','name':'長さと大きさ','description':'同じ長さ・直径・面積などの判断が、周りの形で変わる。'},
 {'id':'direction','name':'傾きと形','description':'平行線、角度、つながり、曲がり方の判断が変わる。'},
 {'id':'depth','name':'奥行きと不可能図形','description':'平面を立体として読むことや、遠近の判断に関わる。'},
 {'id':'light','name':'明るさと明暗の境界','description':'周りの明暗や境界で、同じ明るさが違って見える。'},
 {'id':'color','name':'色と色の変化','description':'照明、周囲の色、順応などで色の見え方が変わる。'},
 {'id':'completion','name':'輪郭と見えない部分の補完','description':'ない輪郭を感じたり、隠れた部分や見えない場所を補ったりする。'},
 {'id':'motion','name':'動きと時間的な位置判断','description':'静止画の動き、仮現運動、速度や方向のずれなど。'},
 {'id':'ambiguity','name':'複数に読める形と立体','description':'同じ入力を、異なる物や奥行きとして解釈できる。'},
 {'id':'attention','name':'注意と周辺の見え方','description':'見落とし、まとまり、混雑、見える時間の判断など。'},
 {'id':'binocular','name':'両眼視と画像の標本化','description':'左右の目の対応や、繰り返す模様の記録に関わる。'}
]
required = ['id','name','english','category','aliases','type','experience','animate','sliderLabel','question','observation','mechanism','check','game','caution','fact','sources','theory']
data=[]
for stem, expected in [('geometry',24),('color',24),('motion',32)]:
 rows=json.loads((WORK/(stem+'.json')).read_text())
 assert len(rows)==expected,(stem,len(rows))
 data.extend(rows)
assert len(data)==80 and len({e['id'] for e in data})==80
for e in data:
 assert all(k in e for k in required),(e['id'],[k for k in required if k not in e])
 assert e['category'] in {c['id'] for c in CATEGORIES},(e['id'],e['category'])
 assert e['experience'] in ['体験','条件付き体験','模式図'],e['id']
 assert e['sources'] and all(s['url'].startswith(('https://','http://')) for s in e['sources']),e['id']
 assert all(isinstance(e[k],str) and e[k].strip() for k in ['name','question','observation','mechanism','check','game','caution','fact']),e['id']
theories=json.loads((WORK/'theories.json').read_text())
by_id={e['id']:e for e in data}
for t in theories:
 assert all(i in by_id for i in t['examples']),t['id']
 assert t['representative'] in by_id,t['id']
(WORK/'catalog.json').write_text(json.dumps({'title':'目の錯覚 図解ガイド','date':'2026-10-31','scope':'主要な錯視と関連現象の整理。全世界の全例を網羅する目録ではない。','categories':CATEGORIES,'theories':theories,'entries':data},ensure_ascii=False,indent=2))
if '--data-only' in sys.argv:
 print('Validated catalog: 80 entries, 12 explanations, 10 categories')
 raise SystemExit(0)

def encoded(obj):
 return json.dumps(obj,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c').replace('\u2028','\\u2028').replace('\u2029','\\u2029')

html=(WORK/'atlas-shell.html').read_text()
for token,value in [
 ('/*__CSS__*/',(WORK/'atlas.css').read_text()),
 ('/*__DATA__*/',encoded(data)),
 ('/*__THEORIES__*/',encoded(theories)),
 ('/*__CATEGORIES__*/',encoded(CATEGORIES)),
 ('/*__RENDERERS__*/','\n'.join((WORK/(x+'.js')).read_text() for x in ['geometry','color','motion'])),
 ('/*__APP__*/',(WORK/'app.js').read_text())
]:
 assert token in html,token
 html=html.replace(token,value)
assert not re.search(r'/\*__[A-Z]+__\*/',html)
(OUT/'visual-illusion-atlas.html').write_text(html)
print(json.dumps({'entries':len(data),'theories':len(theories),'categories':dict(Counter(e['category'] for e in data)),'experience':dict(Counter(e['experience'] for e in data)),'animated':sum(bool(e['animate']) for e in data),'html_bytes':len(html.encode())},ensure_ascii=False,indent=2))
