from pathlib import Path
import json
from collections import Counter
from urllib.parse import urlparse
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE as RT

WORK=Path(__file__).resolve().parent
ROOT=WORK.parent
OUT=ROOT/'output'
catalog=json.loads((WORK/'catalog.json').read_text())
data=catalog['entries'];theories=catalog['theories'];cats=catalog['categories']
by_id={e['id']:e for e in data}
doc=Document();sec=doc.sections[0]
sec.page_width=Inches(8.5);sec.page_height=Inches(11)
sec.top_margin=Inches(.72);sec.bottom_margin=Inches(.68);sec.left_margin=Inches(.75);sec.right_margin=Inches(.75)
sec.header_distance=Inches(.25);sec.footer_distance=Inches(.28)
styles=doc.styles
for name in ['Normal','Title','Subtitle','Heading 1','Heading 2','Heading 3','Caption']:
 st=styles[name];st.font.name='Noto Sans CJK JP';st.font.color.rgb=RGBColor(0,0,0)
 st.element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'Noto Sans CJK JP')
 st.element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:ascii'),'Noto Sans CJK JP')
 st.element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:hAnsi'),'Noto Sans CJK JP')
styles['Normal'].font.size=Pt(11)
styles['Normal'].paragraph_format.line_spacing=Pt(17)
styles['Normal'].paragraph_format.space_after=Pt(6)
styles['Normal'].paragraph_format.widow_control=True
styles['Title'].font.size=Pt(27);styles['Title'].font.bold=True
styles['Title'].paragraph_format.space_after=Pt(12)
styles['Title'].paragraph_format.line_spacing=Pt(37)
styles['Subtitle'].font.size=Pt(12);styles['Subtitle'].paragraph_format.space_after=Pt(14)
styles['Subtitle'].paragraph_format.line_spacing=Pt(19)
for name,size,before,after in [('Heading 1',17,16,10),('Heading 2',13.5,13,7),('Heading 3',11.5,10,5)]:
 st=styles[name];st.font.size=Pt(size);st.font.bold=True;st.paragraph_format.space_before=Pt(before);st.paragraph_format.space_after=Pt(after);st.paragraph_format.keep_with_next=True
 st.paragraph_format.line_spacing=Pt(size*1.5)
styles['Caption'].font.size=Pt(9)
for st in styles:
 if st.type==1:
  ppr=st.element.get_or_add_pPr()
  snap=OxmlElement('w:snapToGrid');snap.set(qn('w:val'),'0');ppr.append(snap)
  for border in list(ppr.findall(qn('w:pBdr'))):ppr.remove(border)
  rpr=st.element.find(qn('w:rPr'))
  if rpr is not None:
   color=rpr.find(qn('w:color'))
   if color is not None:
    for a in ['themeColor','themeTint','themeShade']:color.attrib.pop(qn('w:'+a),None)

def para(txt='',lead=None,small=False):
 p=doc.add_paragraph()
 if lead:p.add_run(lead+' ').bold=True
 p.add_run(txt)
 if small:
  p.paragraph_format.line_spacing=Pt(14)
  for r in p.runs:r.font.size=Pt(9)
 return p
def heading(txt,level=1):return doc.add_heading(txt,level)
def ref_hyperlink(p,text,url):
 rel=p.part.relate_to(url,RT.HYPERLINK,is_external=True)
 a=OxmlElement('w:hyperlink');a.set(qn('r:id'),rel)
 r=OxmlElement('w:r');rp=OxmlElement('w:rPr');co=OxmlElement('w:color');co.set(qn('w:val'),'175C55');rp.append(co)
 u=OxmlElement('w:u');u.set(qn('w:val'),'single');rp.append(u);r.append(rp);t=OxmlElement('w:t');t.text=text;r.append(t);a.append(r);p._p.append(a)
def bookmark(p,name,idx):
 start=OxmlElement('w:bookmarkStart');start.set(qn('w:id'),str(idx));start.set(qn('w:name'),name)
 end=OxmlElement('w:bookmarkEnd');end.set(qn('w:id'),str(idx));p._p.insert(0,start);p._p.append(end)
def table(headers,rows,widths):
 t=doc.add_table(rows=1,cols=len(headers));t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
 for i,(h,w) in enumerate(zip(headers,widths)):t.columns[i].width=Inches(w);t.rows[0].cells[i].text=h
 for row in rows:
  cells=t.add_row().cells
  for cell,txt in zip(cells,row):cell.text=str(txt)
 for ri,row in enumerate(t.rows):
  for ci,cell in enumerate(row.cells):
   cell.width=Inches(widths[ci]);cell.vertical_alignment=WD_ALIGN_VERTICAL.CENTER
   tcpr=cell._tc.get_or_add_tcPr();b=OxmlElement('w:tcBorders')
   for edge in ['top','left','bottom','right']:
    x=OxmlElement('w:'+edge);x.set(qn('w:val'),'single');x.set(qn('w:sz'),'4');x.set(qn('w:color'),'D9D9D9');b.append(x)
   tcpr.append(b)
   mar=OxmlElement('w:tcMar')
   for edge in ['top','left','bottom','right']:
    x=OxmlElement('w:'+edge);x.set(qn('w:w'),'95' if edge in ['top','bottom'] else '105');x.set(qn('w:type'),'dxa');mar.append(x)
   tcpr.append(mar)
   shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'234B46' if ri==0 else ('F0F4F1' if ri%2==0 else 'FFFFFF'));tcpr.append(shade)
   for p in cell.paragraphs:
    p.paragraph_format.space_after=Pt(0);p.paragraph_format.line_spacing=Pt(13.5)
    for r in p.runs:r.font.size=Pt(9);r.font.bold=ri==0;r.font.color.rgb=RGBColor.from_string('FFFFFF' if ri==0 else '000000')
  trpr=row._tr.get_or_add_trPr();cant=OxmlElement('w:cantSplit');trpr.append(cant)
 repeat=OxmlElement('w:tblHeader');t.rows[0]._tr.get_or_add_trPr().append(repeat)
 doc.add_paragraph().paragraph_format.space_after=Pt(0)
 return t

sources=[];source_map={}
def add_source(s):
 if s['url'] not in source_map:
  code='S'+str(len(sources)+1).zfill(3);source_map[s['url']]=code;sources.append({**s,'code':code})
 return source_map[s['url']]
general=[{'title':'Michael Bach  Optical Illusions and Visual Phenomena','url':'https://michaelbach.de/ot/'},{'title':'Bach M and Poloschek CM  Optical Illusions  ACNR 2006','url':'https://michaelbach.de/sci/pubs/BachPolo2006ACNR_illusions.pdf'}]
for s in general:add_source(s)
for e in data:
 for s in e['sources']:add_source(s)
def refs(entries):
 return '、'.join(dict.fromkeys(add_source(s) for e in entries for s in e['sources']))

doc.add_paragraph('目の錯覚の種類と仕組み',style='Title')
doc.add_paragraph('視覚ゲームの制作に向けた80項目の解説資料',style='Subtitle')
para('作成日 2026年10月31日　　対応資料 visual-illusion-atlas.html',small=True)
para('目に入る図と、それを見たときの感じ方が一致しない現象を、ゲームの出題へつなげるための資料です。主要な錯視と関連する視覚現象を10分類の80項目に整理し、説明に使われる12の枠組みをまとめました。各項目には、見え方、説明、確かめ方、ゲームでの使い方、体験条件、参照先を付けています。')
para('同梱のHTMLには、収録した80項目すべてに対応する図を用意しています。文書とHTMLの番号は共通です。まず図を見て判断し、次に「答え・確かめ方を見る」を押すと、周囲を消したり、線や位置を示したりして確かめられます。動く例は開始ボタンを押すまで動きません。')
heading('この資料の範囲')
para('錯覚の名称や分類は研究の目的によって異なり、一つの確定した全件一覧があるわけではありません。また、説明が未解決の現象や、新たに作られる派生図形もあります。本資料は主要な分類を広く見渡すための目録であり、世界中の全例を網羅した一覧ではありません。［S001、S002］')
para('長さや色などが変わって感じられる錯視に加え、注意による見落とし、両眼の情報の統合、画像の記録で生じるずれなども、ゲームとの関係を考えて収録しています。これらをすべて同じ種類の錯視とは扱いません。光の進み方自体が変わる屈折や蜃気楼、視覚以外の錯覚、診断を目的とした現象は収録対象から分けています。')
para('正解を知っても、見え方のずれが残る例があります。そのため「錯覚が見えなくなること」と「見え方に引きずられず、図の条件を確認して答えること」は別の目標です。ゲームでは後者を扱いやすいと考えます。これは本資料の制作上の提案であり、訓練効果を検証した結論ではありません。［S002］')

heading('1 種類を探すための分類')
rows=[]
for c in cats:
 es=[e for e in data if e['category']==c['id']]
 rows.append([c['name'],len(es),c['description']])
table(['分類','件数','主な見え方'],rows,[2.05,.48,4.47])
para('この10分類は、資料を探しやすくするための編集上の整理です。一つの例に複数の仕組みが関係するため、分類は互いに排他的ではありません。たとえば明るさの判断に、輪郭のつながりや影の解釈が関わることもあります。')
heading('図の種類の読み方',2)
counts=Counter(e['experience'] for e in data)
table(['表示','件数','意味'],[
 ['体験',counts['体験'],'画面の図を見て、対応する見え方を試す例です。全員に同じ見え方が起こる保証はありません。'],
 ['条件付き体験',counts['条件付き体験'],'見る位置、距離、周辺視、短い注視など、成立に条件がある例です。'],
 ['模式図',counts['模式図'],'実験条件を再現せず、刺激の配置や説明の関係を示します。見え方そのものを体験したことにはなりません。']
 ],[1.2,.48,5.32])
para('図はすべて本資料のために新しく作図した説明例です。出典の図版、写真、プログラムを転載したものではなく、元の実験条件や錯視の強さをそのまま再現するものでもありません。端末、見る距離、周囲の明るさ、個人差によって体験は変わります。')
para('図の長さや位置に添える数値は、作図用の共通の目盛りです。HTML内では「論理ピクセル」と呼ぶ場合がありますが、端末上の実寸ではありません。また、画面の色は赤・緑・青の強さを0〜255で指定し、この3つの値をRGBと記します。同じ値でも、画面のむらや周囲の明るさまで同じであることは保証しません。',small=True)

doc.add_page_break();heading('2 説明に使う12の枠組み')
para('以下の項目は、独立した12種類の原因がすべて確定しているという意味ではありません。現象を考えるための説明枠組みと、関係する処理を整理したものです。詳細な説明や確かさは、個別の現象ごとに確認してください。')
for t in theories:
 heading(t['id']+' '+t['name'],2)
 para(t['summary'])
 para(t['detail'])
 para(t['term'],lead='用語')
 para(t['limit'],lead='説明の限界')
 example_p=para('、'.join(i+' '+by_id[i]['name'] for i in t['examples']),lead='対応する例',small=True);example_p.paragraph_format.keep_with_next=True
 para('出典 '+refs([by_id[i] for i in t['examples']]),small=True)

heading('3 全80項目の解説')
para('「どう見えるか」は文献で報告される現象の説明です。「この図の事実」は同梱HTMLが描く図の条件です。「ゲームに使うなら」は制作上の提案であり、元の研究で検証されたゲームの効果ではありません。個別の出典は末尾の参照資料一覧から開けます。')
item_num=1
for c in cats:
 heading(c['name'],2)
 para(c['description'])
 for e in [e for e in data if e['category']==c['id']]:
  p=heading(e['id']+' '+e['name'],3);bookmark(p,e['id'],item_num);item_num+=1
  meta=para(e['english']+'　／　'+e['type']+'　／　'+e['experience']+('　／　動きあり' if e['animate'] else ''),small=True);meta.paragraph_format.keep_with_next=True
  if e['aliases']:
   alias_p=para('、'.join(e['aliases']),lead='別名など',small=True);alias_p.paragraph_format.keep_with_next=True
  para(e['observation'],lead='どう見えるか')
  para(e['mechanism'],lead='どう説明されるか')
  para(e['fact']+' '+e['check'],lead='この図の事実と確かめ方')
  para(e['game'],lead='ゲームに使うなら')
  caution_p=para(e['caution'],lead='体験条件と限界');caution_p.paragraph_format.keep_with_next=True
  para('HTMLの番号 '+e['id']+'　出典 '+refs([e]),small=True)

heading('4 ゲームへつなげる考え方')
para('以下は、収録した現象を使って出題するための制作提案です。錯視の強さや学習の効果を本資料で実測したものではありません。最初は、線の長さ、円の直径、画面に指定した色、対象の移動量など、正解をプログラム上で確認できるものから作ると検証しやすくなります。')
heading('正解を何で決めるか',2)
table(['出題の種類','代表例','正解の確認方法'],[
 ['長さや大きさを比べる','G01、G03、G04','線の両端の距離や、円の直径を比較する。'],
 ['平行かどうかを答える','G09、G10、G14','線の傾きや、延長した交点を確認する。'],
 ['画面の色を比べる','C01、C02、C11','画面へ指定した色の値を比較する。'],
 ['本当に動いているか答える','M04、M05、M13','画像の座標、移動量、速度を確認する。'],
 ['どこが変わったか探す','M23','前後の図のどの属性を変えたかを記録する。']
 ],[1.75,1.25,4])
heading('問題を出して確かめる流れ',2)
para('最初に「画面上で実際に長いのはどちらか」と聞きます。次に補助線を表示したり、背景を消したりして正解の根拠を見せます。最後に長さや配置を少し変えて再び出題します。毎回「同じ」が正解になる構成を避け、本当に差がある問題も混ぜると、答えだけを覚える攻略を防ぎやすくなります。')
para('難易度は、制限時間だけでなく、周りの模様の強さや対象同士の差で調整できます。「長く見えるもの」と「実際に長いもの」が混同されないよう、設問の文言を固定します。スマートフォンの小さな画面でも対象や操作が隠れない配置を選びます。')
heading('得点を付けにくい例',2)
para('多義図形でどちらの解釈が先に見えたか、残像がどれほど強く見えたかなどは、唯一の正解を決めにくい課題です。立体視や周辺視を使う現象も、見方や個人差の影響を受けます。これらは、別の解釈を発見したり、図の成り立ちを説明したりする問題として扱う方が適しています。')
heading('表現と検証の範囲',2)
para('本資料は一般的な認知能力が向上することや、錯覚にかからなくなることを検証していません。「脳トレ」と呼ぶ場合でも、具体的に何を練習するのかを示し、効果を保証する表現は避けます。まずは、表示の条件を確かめて判断する体験として評価します。')
para('HTMLでは動きを利用者が開始したときだけ再生し、通常は20秒以内で止めます。残像や残効の例では、刺激を見せる時間をさらに短くしています。長時間の誘導が必要な例は模式図としています。見づらい場合は停止してください。')
heading('資料の限界',2)
para('各図が表示できることと、狙った錯視が十分に起こることは別です。図の座標や同じ色の値、各操作の動作は実装から確認できますが、人の感じ方や錯視の強さはこの資料だけでは確定できません。実際のゲームに採用する前に、対象端末と複数の人で見え方を確認してください。')

heading('5 参照資料')
para('参照日はいずれも2026年10月31日です。研究者が公開する解説、大学の資料、研究論文などを参照しました。各項目の参照番号は、この一覧の番号と対応しています。リンクは元の掲載先を開きます。')
for s in sources:
 p=doc.add_paragraph();p.paragraph_format.space_before=Pt(5);p.paragraph_format.space_after=Pt(2);p.paragraph_format.keep_with_next=True
 p.add_run(s['code']+'　').bold=True;ref_hyperlink(p,s['title'],s['url'])
 p2=para(s['url'],small=True);p2.paragraph_format.space_after=Pt(5)

foot=sec.footer.paragraphs[0];foot.alignment=WD_ALIGN_PARAGRAPH.RIGHT
run=foot.add_run('目の錯覚の種類と仕組み　');run.font.name='Noto Sans CJK JP';run.font.size=Pt(8);run.font.color.rgb=RGBColor(90,90,90)
fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');foot._p.append(fld)
doc.core_properties.title='目の錯覚の種類と仕組み'
doc.core_properties.subject='視覚ゲーム制作に向けた80項目と12の説明枠組み'
doc.core_properties.author='ChatGPT'
doc.core_properties.keywords='錯視 視覚 ゲーム 図解 理論'
doc.core_properties.comments=''
for border in list(doc.element.xpath('.//w:pBdr')):border.getparent().remove(border)
for grid in list(doc.element.xpath('.//w:docGrid')):grid.getparent().remove(grid)
out=OUT/'visual-illusion-guide.docx';doc.save(out)
(WORK/'bibliography.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2))
print(json.dumps({'path':str(out),'bytes':out.stat().st_size,'sources':len(sources),'entries':len(data)},ensure_ascii=False))
